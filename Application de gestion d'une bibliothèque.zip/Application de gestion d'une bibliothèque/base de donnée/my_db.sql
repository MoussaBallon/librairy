-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 16 août 2024 à 14:06
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `my_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `auteurs`
--

CREATE TABLE `auteurs` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `bio` text NOT NULL,
  `link` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `auteurs`
--

INSERT INTO `auteurs` (`id`, `nom`, `bio`, `link`) VALUES
(36, 'Robert C. ', 'souvent connu sous le nom de \"Uncle Bob\", est un développeur de logiciels renommé, consultant et auteur. Il est particulièrement célèbre pour ses contributions dans le domaine de l\'ingénierie logicielle et pour avoir popularisé des concepts importants tels que les principes SOLID de conception orientée objet.\r\n\r\n                    **Biographie succincte :**\r\n                    \r\n                    - **Nom complet :** Robert Cecil Martin\r\n                    - **Surnom :** Uncle Bob\r\n                    - **Date de naissance :** 5 décembre 1952\r\n                    - **Profession :** Développeur de logiciels, consultant, auteur\r\n                    \r\n                    **Carrière :**\r\n                    \r\n                    Robert C. Martin a commencé sa carrière dans le développement de logiciels dans les années 1970. Il a fondé Object Mentor, une société de conseil en développement de logiciels, qui a aidé de nombreuses entreprises à améliorer leurs processus de développement et à adopter des pratiques de programmation plus efficaces.\r\n                    \r\n                    **Contributions :**\r\n                    \r\n                    1. **Principes SOLID :** Martin est largement reconnu pour avoir formulé et popularisé les principes SOLID, un ensemble de cinq principes de conception orientée objet qui aident les développeurs à créer des logiciels plus robustes et maintenables.\r\n                       \r\n                    2. **Méthodes Agiles :** Il est un des signataires originaux du Manifeste Agile, un document fondamental qui a jeté les bases des méthodologies de développement agile. Martin a également écrit plusieurs livres sur les pratiques agiles, dont \"Agile Software Development, Principles, Patterns, and Practices\".\r\n                       \r\n                    3. **Livres et Publications :** Il a écrit plusieurs livres influents dans le domaine du développement logiciel, notamment \"Clean Code: A Handbook of Agile Software Craftsmanship\" et \"The Clean Coder: A Code of Conduct for Professional Programmers\". Ces ouvrages sont considérés comme des références pour les développeurs cherchant à améliorer la qualité de leur code et leur professionnalisme.\r\n                    \r\n                    **Philosophie :**\r\n                    \r\n                    Robert C. Martin prône une approche rigoureuse et disciplinée du développement logiciel, mettant l\'accent sur la qualité du code, la simplicité, et la pratique continue. Il croit fermement que les développeurs doivent adopter une attitude professionnelle et éthique dans leur travail, en adhérant à des standards élevés de qualité et de responsabilité.\r\n                    \r\n                    En tant qu\'orateur et formateur, Martin continue d\'influencer la communauté des développeurs de logiciels à travers ses conférences, ateliers et publications, inspirant de nombreuses personnes à améliorer leurs compétences et à adopter des pratiques de développement plus efficaces.', 'RobertC.php'),
(37, 'Seydou Badien ', '                    Seydou Badian Kouyaté (1928-2018) était un écrivain et homme politique malien. Né à Bamako, alors partie du Soudan français, il a fait ses études secondaires à Bamako avant de poursuivre des études de médecine en France, où il a obtenu son diplôme de docteur en médecine en 1956.\r\n\r\n                    De retour au Mali, Seydou Badian a rapidement pris une place importante dans la politique de son pays nouvellement indépendant. Il a été nommé ministre de l\'Économie rurale et du Plan sous la présidence de Modibo Keïta. Plus tard, il a été ministre du Développement et de la Coopération internationale. Son engagement politique a été marqué par sa volonté de développer le Mali en s\'appuyant sur ses propres ressources et en valorisant les cultures locales.\r\n                    \r\n                    En tant qu\'écrivain, Seydou Badian est surtout connu pour son roman \"Sous l\'orage\" (1957), qui traite des conflits entre les valeurs traditionnelles africaines et les influences occidentales. Ses autres œuvres importantes incluent \"Le Sang des masques\" (1976) et \"Noces sacrées\" (1977). Ses écrits sont souvent centrés sur la lutte pour l\'identité africaine et la résistance à la domination coloniale.\r\n                    \r\n                    En plus de ses contributions littéraires, Seydou Badian était également un fervent défenseur de l\'unité africaine et a travaillé à promouvoir l\'idée d\'une Afrique indépendante et prospère. Sa vie et son œuvre continuent d\'inspirer de nombreuses personnes à travers le continent africain et au-delà.', 'Seydou.php'),
(38, 'Amadou Hampathé Bah', 'Amadou Hampaté Bâ (1901-1991) était un éminent écrivain et ethnologue malien. Né à Bandiagara, dans l\'actuel Mali, il a consacré sa vie à la préservation et à la transmission des traditions orales africaines. <br> \r\n\r\n <br> Élevé dans une famille peule, il a étudié dans des écoles coraniques et françaises. Après ses études, il a travaillé pour l\'administration coloniale française avant de se tourner vers la recherche et l\'écriture. Il a rejoint l\'Institut français d\'Afrique noire (IFAN) à Dakar, où il a mené des recherches approfondies sur les cultures et les traditions de l\'Afrique de l\'Ouest. <br>\r\n\r\n <br>  Amadou Hampaté Bâ est surtout connu pour sa célèbre phrase : \"En Afrique, un vieillard qui meurt est une bibliothèque qui brûle\", soulignant l\'importance de la tradition orale et de la sagesse des anciens. <br> Parmi ses œuvres les plus notables figurent \"L\'Étrange Destin de Wangrin\" et \"Amkoullel l\'enfant peul\", où il raconte ses mémoires et offre un aperçu précieux de la vie africaine traditionnelle.\r\n\r\nIl a également joué un rôle crucial dans la promotion des langues africaines et a été membre du Conseil exécutif de l\'UNESCO. Grâce à ses efforts inlassables, il a contribué à la préservation de la richesse culturelle de l\'Afrique pour les générations futures.', 'Amadou.php'),
(39, 'Anne Boehm', ' Anne Boehm est une auteure et développeuse de logiciels reconnue pour ses contributions dans le domaine de l\'éducation en programmation et en développement de logiciels. Elle est surtout connue pour ses ouvrages pédagogiques qui aident les débutants et les professionnels à maîtriser divers langages de programmation et technologies de développement.\r\n\r\n                    **Biographie succincte :**\r\n                    \r\n                    - **Nom complet :** Anne Boehm\r\n                    - **Profession :** Auteure, développeuse de logiciels, formatrice\r\n                    \r\n                    **Carrière et Contributions :**\r\n                    \r\n                    1. **Ouvrages pédagogiques :** Anne Boehm a coécrit plusieurs livres avec Mike Murach, un autre auteur renommé dans le domaine de la programmation. Leurs livres sont particulièrement appréciés pour leur clarté, leur approche pédagogique et leur pertinence pratique. Parmi ses œuvres les plus connues, on trouve des manuels sur des technologies comme C#, Visual Basic, ASP.NET et SQL Server.\r\n                    \r\n                    2. **Murach\'s Books:** Ses ouvrages sont publiés par Murach\'s Books, une maison d\'édition réputée pour ses ressources éducatives en informatique. Les livres d\'Anne Boehm sont largement utilisés dans les écoles, les collèges et les programmes de formation professionnelle pour enseigner la programmation et le développement de logiciels.\r\n                    \r\n                    3. **Approche pédagogique :** Les livres d\'Anne Boehm sont connus pour leur style convivial et structuré, rendant l\'apprentissage des concepts complexes plus accessible. Ils incluent souvent des exemples pratiques, des exercices et des explications détaillées pour aider les lecteurs à comprendre et à appliquer les concepts de programmation.\r\n                    \r\n                    **Philosophie :**\r\n                    \r\n                    Anne Boehm croit fermement en l\'importance de rendre la programmation accessible à tous, indépendamment de leur niveau d\'expérience. Elle met l\'accent sur une approche pratique de l\'apprentissage, où les étudiants peuvent immédiatement appliquer ce qu\'ils ont appris à travers des exercices et des projets concrets.\r\n                    \r\n                    Grâce à ses contributions significatives dans le domaine de l\'éducation en programmation, Anne Boehm a aidé de nombreux étudiants et professionnels à développer leurs compétences en développement de logiciels, faisant d\'elle une figure respectée et influente dans le domaine de la formation en informatique.', 'Anne.php'),
(40, 'Robert Cialdini', ' Robert Cialdini est un psychologue social américain et professeur émérite de psychologie et de marketing à l\'Université d\'État de l\'Arizona. Il est mondialement reconnu pour ses travaux sur la psychologie de la persuasion et de l\'influence sociale.\r\n\r\n                    **Biographie succincte :**\r\n                    \r\n                    - **Nom complet :** Robert Beno Cialdini\r\n                    - **Date de naissance :** 27 avril 1945\r\n                    - **Profession :** Psychologue, auteur, conférencier\r\n                    \r\n                    **Carrière :**\r\n                    \r\n                    Cialdini a obtenu son doctorat en psychologie sociale de l\'Université de Caroline du Nord à Chapel Hill et a effectué un stage postdoctoral à l\'Université Columbia. Il a passé sa carrière universitaire à l\'Université d\'État de l\'Arizona, où il a enseigné la psychologie et le marketing.\r\n                    \r\n                    **Contributions :**\r\n                    \r\n                    1. **Principes d\'influence :** Cialdini est surtout connu pour son livre \"Influence: The Psychology of Persuasion\" (1984), qui présente six principes fondamentaux de l\'influence : la réciprocité, l\'engagement et la cohérence, la preuve sociale, l\'autorité, la sympathie et la rareté. Ces principes expliquent comment et pourquoi les gens peuvent être influencés par les autres.\r\n                    \r\n                    2. **Travaux et recherches :** Ses recherches ont été largement citées et appliquées dans divers domaines, y compris le marketing, la vente, le management et la négociation. Ses travaux sont basés sur des expériences scientifiques rigoureuses et des observations pratiques, ce qui les rend très crédibles et applicables.\r\n                    \r\n                    3. **Publications et livres :** Outre \"Influence\", Cialdini a écrit plusieurs autres livres importants, dont \"Pre-Suasion: A Revolutionary Way to Influence and Persuade\" (2016), qui explore comment préparer le terrain pour rendre les messages de persuasion plus efficaces.\r\n                    \r\n                    4. **Conférences et formation :** En tant que conférencier et formateur, Cialdini a travaillé avec de nombreuses entreprises et organisations à travers le monde pour les aider à comprendre et à appliquer les principes de persuasion dans leurs pratiques commerciales et de communication.\r\n                    \r\n                    **Philosophie :**\r\n                    \r\n                    Robert Cialdini prône une approche éthique de la persuasion, soulignant que l\'influence doit être utilisée de manière responsable et pour le bien de toutes les parties impliquées. Il met en garde contre l\'utilisation abusive des techniques de persuasion, car elles peuvent conduire à une perte de confiance et de crédibilité à long terme.\r\n                    \r\n                    Grâce à ses contributions significatives, Cialdini a profondément influencé la manière dont la persuasion est comprise et pratiquée dans de nombreux domaines, faisant de lui une figure incontournable dans le domaine de la psychologie sociale et du marketing.', 'Cialdini.php');

-- --------------------------------------------------------

--
-- Structure de la table `catégories`
--

CREATE TABLE `catégories` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `link` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `catégories`
--

INSERT INTO `catégories` (`id`, `nom`, `link`) VALUES
(15, 'Developpement Web', 'dev.php'),
(17, 'Marketing', 'marketing.php'),
(18, 'Divers', 'diver.php'),
(19, 'animer', 'aimer.php');

-- --------------------------------------------------------

--
-- Structure de la table `livres`
--

CREATE TABLE `livres` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `categorie_id` int(11) DEFAULT NULL,
  `auteur_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `livres`
--

INSERT INTO `livres` (`id`, `title`, `categorie_id`, `auteur_id`, `description`, `link`) VALUES
(46, 'html', 15, 36, '                                Édition recommandée : \"Murach\'s HTML and CSS (5th Edition)\"\r\n                                Auteurs : Anne Boehm, Zak Ruvalcaba\r\n                                Éditeur : Mike Murach & Associates\r\n                                Date de publication : 1er avril 2021\r\n                                ISBN : 978-1943872852\r\n                                Description :\r\n                                \"Murach\'s HTML and CSS (5th Edition)\" est un manuel complet et pratique conçu pour les débutants comme pour les développeurs expérimentés qui souhaitent approfondir leurs compétences en HTML et CSS.\r\n\r\n                                Ce livre adopte une approche unique de présentation en double page :\r\n\r\n                                La page de gauche fournit des explications claires et détaillées des concepts, des techniques et des pratiques liées au développement web.\r\n                                La page de droite propose des exemples concrets de code et des exercices pour appliquer les concepts appris.\r\n                                Contenu principal :\r\n                                Introduction aux bases du HTML et CSS : Ce livre commence par les fondamentaux du HTML5 et du CSS3, expliquant comment structurer et styliser les pages web de manière efficace.\r\n                                Conception responsive : Les auteurs mettent l\'accent sur la création de sites web adaptatifs qui fonctionnent bien sur une variété d\'appareils et de tailles d\'écran.\r\n                                Techniques avancées : Le livre couvre également des sujets avancés tels que les formulaires, les tableaux, les flexbox, les grilles CSS et les animations.\r\n                                Projets pratiques : Plusieurs chapitres incluent des projets pratiques et des études de cas réels pour renforcer l\'apprentissage et permettre aux lecteurs de voir comment appliquer les techniques dans des contextes réels.\r\n                                Avec son approche didactique et ses exemples concrets, \"Murach\'s HTML and CSS\" est une ressource précieuse pour toute personne souhaitant maîtriser la création de sites web modernes et attrayants.', 'html&css.php'),
(47, 'sous l\'orage', 17, 37, '\"Clean Code: A Handbook of Agile Software Craftsmanship\" est un guide pratique pour écrire du code propre, maintenable et évolutif. Robert C. Martin partage ses décennies d\'expérience et propose des principes, des pratiques et des astuces pour éviter les pièges courants du développement logiciel. Le livre est divisé en trois parties :\r\n                    \r\n                    Les principes et les meilleures pratiques du code propre : Cette partie couvre les techniques essentielles pour écrire du code lisible et bien structuré.\r\n                    Les études de cas : Martin propose plusieurs études de cas de code \"sale\" qu\'il refactorise en code propre, illustrant ainsi les concepts présentés dans la première partie.\r\n                    Les heuristiques et les \"smells\" de code : Cette partie offre une liste de conseils pratiques et de mauvaises pratiques à éviter pour maintenir la propreté du code.\r\n                    \"Clean Code\" est largement apprécié pour sa clarté, ses exemples concrets et son approche pragmatique, faisant de lui une ressource précieuse pour les développeurs de tous niveaux.', 'S1.php'),
(48, 'mali', 15, 37, '\"Clean Code: A Handbook of Agile Software Craftsmanship\" est un guide pratique pour écrire du code propre, maintenable et évolutif. Robert C. Martin partage ses décennies d\'expérience et propose des principes, des pratiques et des astuces pour éviter les pièges courants du développement logiciel. Le livre est divisé en trois parties :\r\n                    \r\n                    Les principes et les meilleures pratiques du code propre : Cette partie couvre les techniques essentielles pour écrire du code lisible et bien structuré.\r\n                    Les études de cas : Martin propose plusieurs études de cas de code \"sale\" qu\'il refactorise en code propre, illustrant ainsi les concepts présentés dans la première partie.\r\n                    Les heuristiques et les \"smells\" de code : Cette partie offre une liste de conseils pratiques et de mauvaises pratiques à éviter pour maintenir la propreté du code.\r\n                    \"Clean Code\" est largement apprécié pour sa clarté, ses exemples concrets et son approche pragmatique, faisant de lui une ressource précieuse pour les développeurs de tous niveaux.', 'S2.php'),
(49, 'Node.js', 15, 39, '\"Clean Code: A Handbook of Agile Software Craftsmanship\" est un guide pratique pour écrire du code propre, maintenable et évolutif. Robert C. Martin partage ses décennies d\'expérience et propose des principes, des pratiques et des astuces pour éviter les pièges courants du développement logiciel. Le livre est divisé en trois parties :\r\n                    \r\n                    Les principes et les meilleures pratiques du code propre : Cette partie couvre les techniques essentielles pour écrire du code lisible et bien structuré.\r\n                    Les études de cas : Martin propose plusieurs études de cas de code \"sale\" qu\'il refactorise en code propre, illustrant ainsi les concepts présentés dans la première partie.\r\n                    Les heuristiques et les \"smells\" de code : Cette partie offre une liste de conseils pratiques et de mauvaises pratiques à éviter pour maintenir la propreté du code.\r\n                    \"Clean Code\" est largement apprécié pour sa clarté, ses exemples concrets et son approche pragmatique, faisant de lui une ressource précieuse pour les développeurs de tous niveaux.', 'node.php'),
(50, 'Réseaux Informatiques', 15, 40, '\"Clean Code: A Handbook of Agile Software Craftsmanship\" est un guide pratique pour écrire du code propre, maintenable et évolutif. Robert C. Martin partage ses décennies d\'expérience et propose des principes, des pratiques et des astuces pour éviter les pièges courants du développement logiciel. Le livre est divisé en trois parties :\r\n                    \r\n                    Les principes et les meilleures pratiques du code propre : Cette partie couvre les techniques essentielles pour écrire du code lisible et bien structuré.\r\n                    Les études de cas : Martin propose plusieurs études de cas de code \"sale\" qu\'il refactorise en code propre, illustrant ainsi les concepts présentés dans la première partie.\r\n                    Les heuristiques et les \"smells\" de code : Cette partie offre une liste de conseils pratiques et de mauvaises pratiques à éviter pour maintenir la propreté du code.\r\n                    \"Clean Code\" est largement apprécié pour sa clarté, ses exemples concrets et son approche pragmatique, faisant de lui une ressource précieuse pour les développeurs de tous niveaux.', 'R1.php'),
(51, 'Dictionnaire des trans & logi', 17, 36, ' \"Clean Code: A Handbook of Agile Software Craftsmanship\" est un guide pratique pour écrire du code propre, maintenable et évolutif. Robert C. Martin partage ses décennies d\'expérience et propose des principes, des pratiques et des astuces pour éviter les pièges courants du développement logiciel. Le livre est divisé en trois parties :\r\n                    \r\n                    Les principes et les meilleures pratiques du code propre : Cette partie couvre les techniques essentielles pour écrire du code lisible et bien structuré.\r\n                    Les études de cas : Martin propose plusieurs études de cas de code \"sale\" qu\'il refactorise en code propre, illustrant ainsi les concepts présentés dans la première partie.\r\n                    Les heuristiques et les \"smells\" de code : Cette partie offre une liste de conseils pratiques et de mauvaises pratiques à éviter pour maintenir la propreté du code.\r\n                    \"Clean Code\" est largement apprécié pour sa clarté, ses exemples concrets et son approche pragmatique, faisant de lui une ressource précieuse pour les développeurs de tous niveaux.', 'L3.php');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(10) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `user_name`, `password`, `email`, `role`) VALUES
(13, 'papa', '$2y$10$7HLLhoto19qX2Q0Jc4GOL.9nk/1gIE3JJlLeITje8pZdMZxDxLgeK', 'papa@p.com', 'user'),
(17, 'Ive', '$2y$10$V9khAJK4xOMuuWCvu/MYZ.kplR.ndCDyYP2Rtaf49kVPYwka7tdI6', 'ive@ive.com', 'admin'),
(39, 'Admin', '$2y$10$vj34z7B0k0JB93XpbnQI3O6NZG.0JLXn2SF/eXIsXLBWK6DyXCBW2', 'Admin@admin.com', 'admin'),
(48, 'med', '$2y$10$DOXfKiEmu9fyDR3bczvKZuzyG.reskiE5gt6FgR.oW0/X6ZNPDUg2', 'sm.medmohamed@gmail.com', 'user');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `auteurs`
--
ALTER TABLE `auteurs`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `catégories`
--
ALTER TABLE `catégories`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `livres`
--
ALTER TABLE `livres`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categorie_id` (`categorie_id`),
  ADD KEY `auteur_id` (`auteur_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `auteurs`
--
ALTER TABLE `auteurs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT pour la table `catégories`
--
ALTER TABLE `catégories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT pour la table `livres`
--
ALTER TABLE `livres`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `livres`
--
ALTER TABLE `livres`
  ADD CONSTRAINT `livres_ibfk_1` FOREIGN KEY (`categorie_id`) REFERENCES `catégories` (`id`),
  ADD CONSTRAINT `livres_ibfk_2` FOREIGN KEY (`auteur_id`) REFERENCES `auteurs` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
