<?php
session_start();


if  (isset($_POST['envoi'])) {
    include 'db_connect.php';
    $user_name = $_POST['user_name'];
    $password = $_POST['password'];

    // Requête SQL pour vérifier l'utilisateur
    $sql = "SELECT * FROM users WHERE user_name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $user_name);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Vérifier le mot de passe
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_name'] = $user['user_name'];
            $_SESSION['role'] = $user['role']; // Stocker le rôle de l'utilisateur dans la session

            // Redirection en fonction du rôle
            if ($user['role'] === 'admin') {
                header("Location: ../page/admin_home.php");
            } else {
                header("Location: ../page/main.php");
            }
            exit();
        } else {
            $_SESSION['error_message'] = 'Nom ou mot de passe invalide !!!';
        }
    } else {
        $_SESSION['error_message'] = 'Aucun utilisateur ne correspond au mot de passe !!!';
    }
    $stmt->close();
    $conn->close();

    header("Location: ../page/login.php");
    exit();
}
