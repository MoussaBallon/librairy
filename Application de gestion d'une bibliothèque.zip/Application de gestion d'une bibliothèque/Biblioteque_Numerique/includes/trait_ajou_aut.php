<?php
session_start();
include 'db_connect.php';

// Vérifier si l'utilisateur est connecté et s'il est administrateur
if (!isset($_SESSION['user_name']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../page/login.php");
    exit();
}

if (isset($_POST['ajouter'])) {
    $nom = $_POST['nom'];
    $link = $_POST['link'];
    $bio = $_POST['bio'];

    // Préparation de la requête SQL pour insérer l'auteur
    $sql = "INSERT INTO auteurs (nom, link, bio) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $nom, $link, $bio);

    if ($stmt->execute()) {
        // Redirection vers la page de gestion des auteurs avec un message de succès
        $_SESSION['message'] = "Auteur ajouter avec success!";
        header("Location: ../page/admin_ajou_aut.php");
    } else {
        // Redirection vers la page d'ajout d'auteur avec un message d'erreur
        $_SESSION['error'] = "Failed to add author.";
        header("Location: ../page/admin_ajou_aut.php");
    }

    $stmt->close();
}
if (isset($_POST['annuler'])){
    header("Location: ../page/admin_ajou_aut.php");
    exit();
}

$conn->close();

