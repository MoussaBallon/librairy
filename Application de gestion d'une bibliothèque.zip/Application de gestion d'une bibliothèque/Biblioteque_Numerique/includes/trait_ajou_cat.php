<?php
session_start();
include 'db_connect.php';

// Vérifier si l'utilisateur est connecté et s'il est administrateur
if (!isset($_SESSION['user_name']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../page/login.php");
    exit();
}

if (isset($_POST['ajouter'])) {
    $nom = $_POST['nom'];
    $link = $_POST['link'];

    // Préparation de la requête SQL pour insérer l'auteur
    $sql = "INSERT INTO catégories (nom, link) VALUE (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $nom, $link);

    if ($stmt->execute()) {
        // Redirection vers la page de gestion des auteurs avec un message de succès
        $_SESSION['message'] = ('" Catégorie ajouter avec success!"');
        header("Location: ../page/admin_ajou_cat.php");
    } else {
        // Redirection vers la page d'ajout d'auteur avec un message d'erreur
        $_SESSION['error'] = "Failed to add author.";
        header("Location: ../page/admin_ajou_cat.php");
    }

    $stmt->close();
}
if (isset($_POST['annuler'])){
    header("Location: ../page/admin_ajou_cat.php");
    exit();
}

$conn->close();

