<?php
session_start();
include 'db_connect.php';

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_name']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $liv_id = $_POST['id'];
    $title = $_POST['title'];
    $link = $_POST['link'];
    $category_id = $_POST['categorie_id'];
    $author_id = $_POST['auteur_id'];
    $description = $_POST['description'];
        // Afficher les valeurs pour vérification
        echo "Book ID: $liv_id, Title: $title, Description: $description, Category ID: $category_id, Author ID: $author_id<br>";
            // Vérifiez que l'auteur et la catégorie existent dans la base de données
                $author_check_sql = "SELECT id FROM auteurs WHERE id = ?";
                $category_check_sql = "SELECT id FROM catégories WHERE id = ?";
        //...

    // Vérifiez que l'auteur et la catégorie existent dans la base de données
 
    
    $author_stmt = $conn->prepare($author_check_sql);
    $author_stmt->bind_param("i", $author_id);
    $author_stmt->execute();
    $author_stmt->store_result();
    
    $category_stmt = $conn->prepare($category_check_sql);
    $category_stmt->bind_param("i", $category_id);
    $category_stmt->execute();
    $category_stmt->store_result();
 
    
    if ($author_stmt->num_rows > 0 && $category_stmt->num_rows > 0) {
        // Mettre à jour le livre dans la base de données
        $sql = "UPDATE livres SET title = ?, link = ?, categorie_id = ?, auteur_id = ?, description = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssiisi", $title, $link, $category_id, $author_id, $description, $liv_id);

        if ($stmt->execute()) {
            $_SESSION["messagem"] = "modifications réussi";
            header("Location: ../page/admin_list_liv.php");
            exit();
        } else {
            echo "Erreur lors de la mise à jour de l'enregistrement: " . $conn->error;
        }

        $stmt->close();
    } else {
        echo "Auteur ou catégorie non trouvé dans la base de données.";
    }

    $author_stmt->close();
    $category_stmt->close();
}

$conn->close();

