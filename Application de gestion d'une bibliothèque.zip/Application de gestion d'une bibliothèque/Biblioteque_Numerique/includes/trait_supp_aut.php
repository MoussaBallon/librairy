<?php
session_start();
include '../includes/db_connect.php';

if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}

if (isset($_POST['delete'])) {
    $auteur_id = $_POST['auteur_id'];

    $sql = "DELETE FROM auteurs WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $auteur_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Auteur éffacer de la base de donnée !!";
        header("Location: ../page/admin_list_aut.php");
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }

    $stmt->close();
}

$conn->close();

