<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_POST['envoi'])) {
    include 'db_connect.php';

    $user_name = $_POST['user_name'];
    $password = $_POST['password'];

    if (empty($user_name) || empty($password)) {
        $_SESSION['error_message'] = 'Please fill in all fields.';
        header("Location: ../page/login.php");
        exit();
    }

    $sql = "SELECT password FROM users WHERE user_name = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Prepare statement failed: " . $conn->error);
    }

    $stmt->bind_param("s", $user_name);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($hashed_password);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_name'] = $user_name;
            header("Location: ../page/main.php");
            exit();
        } else {
            $_SESSION['error_message'] = 'Nom ou mot de passe invalide !!!';
        }
    } else {
        $_SESSION['error_message'] = 'Aucun utilisateur ne correspond au mot de passe !!!';
    }

    $stmt->close();
    $conn->close();

    header("Location: ../page/login.php");
    exit();
}

