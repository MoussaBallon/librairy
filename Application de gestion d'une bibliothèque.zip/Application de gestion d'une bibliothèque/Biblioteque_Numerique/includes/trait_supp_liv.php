<?php
session_start();
include '../includes/db_connect.php';

if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}

if (isset($_POST['delete'])) {
    $book_id = $_POST['book_id'];

    $sql = "DELETE FROM livres WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $book_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Livre effacer de la base de donnée !!";
        header("Location: ../page/admin_list_liv.php");
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }

    $stmt->close();
}

$conn->close();

