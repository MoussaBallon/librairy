<?php
session_start();
include '../includes/db_connect.php';

if (!isset($_SESSION['user_name']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

if (isset($_POST["updated"])) {
    $cat_id = $_POST['id'];
    $nom = $_POST['nom'];
    $link = $_POST['link'];

    // Mettre à jour l'auteur dans la base de données
    $sql = "UPDATE catégories SET nom = ?, link = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $nom, $link, $cat_id);

    if ($stmt->execute()) {
        $_SESSION["mes1"] = "Modifications réussie";
        header("Location:../page/admin_list_cat.php");
        exit();
    } else {
        echo "Erreur lors de la mise à jour de l'enregistrement: " . $conn->error;
    }

    $stmt->close();
}

$conn->close();
