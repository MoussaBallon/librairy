<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_POST['envoi'])) {
    include 'db_connect.php';

    $user_name = $_POST['user_name'];
    $email = $_POST['email'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if ($new_password !== $confirm_password) {
        $_SESSION['error_message'] = 'le mot de passe ne correspond pas !!!.';
        header("Location: ../page/signup.php");
        exit();
    }

    $sql = "SELECT email FROM users WHERE user_name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $user_name);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($db_email);
        $stmt->fetch();

        if ($db_email === $email) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update_sql = "UPDATE users SET password = ? WHERE user_name = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("ss", $hashed_password, $user_name);

            if ($update_stmt->execute()) {
                $_SESSION['success_message'] = 'Mot de passe mise a jours avec succes. Vous pouvez maintenant vous connecter avec !.';
                header("Location: ../page/login.php");
                exit();
            } else {
                $_SESSION['error_message'] = 'Erreur dans la mise a jour. Veillez réesailler.';
            }

            $update_stmt->close();
        } else {
            $_SESSION['error_message'] = 'Email ne correspond a celui enregistrer pour cet utilisateur.';
        }
    } else {
        $_SESSION['error_message'] = 'Ce Non ne correspond à aucun utilisateur !.';
    }

    $stmt->close();
    $conn->close();

    header("Location: ../page/signup.php");
    exit();
}
