<?php
session_start();
include '../includes/db_connect.php';

if (!isset($_SESSION['user_name']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

if (isset($_POST["updated"])) {
    $etu_id = $_POST['id'];
    $user_name = $_POST['user_name'];
    $email = $_POST['email'];
    $role = $_POST['role'];

    // Mettre à jour l'auteur dans la base de données
    $sql = "UPDATE users SET user_name = ?, email = ?, role = ?  WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $user_name, $email, $role, $etu_id);

    if ($stmt->execute()) {
        $_SESSION["mes"] = "Modification réussie";
        header("Location:../page/admin_list_etu.php");
        exit();
    } else {
        header("Location : ../page/admin_list_etu.php");
        echo "Erreur lors de la mise à jour de l'enregistrement: " . $conn->error;
    } 


    $stmt->close();
}
if (isset($_POST['annuler'])){
    header("Location: ../page/admin_list_etu.php");
    exit();
}

$conn->close();

