<?php
session_start();
include '../includes/db_connect.php';

if (!isset($_SESSION['user_name']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}



if (isset($_POST['annuler'])){
    header("Location: ../page/admin_list_aut.php");
    exit();
}



if (isset($_POST["update"])) {
    $author_id = $_POST['id'];
    $nom = $_POST['nom'];
    $bio = $_POST['bio'];

    // Mettre à jour l'auteur dans la base de données
    $sql = "UPDATE auteurs SET nom = ?, bio = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $nom, $bio, $author_id);

    if ($stmt->execute()) {
        $_SESSION["mes"] = "Modification réussie";
        header("Location:../page/admin_list_aut.php");
        exit();
    } else {
        echo "Erreur lors de la mise à jour de l'enregistrement: " . $conn->error;
    }
    
    
    $stmt->close();

}

$conn->close();

$conn->close();