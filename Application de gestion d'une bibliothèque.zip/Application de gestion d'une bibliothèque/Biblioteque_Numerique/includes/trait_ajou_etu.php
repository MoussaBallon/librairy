<?php
session_start();
if (isset($_POST['ajouter'])) {
    include 'db_connect.php';
    // Vérifier si l'utilisateur est connecté et s'il est administrateur
if (!isset($_SESSION['user_name']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../page/login.php");
    exit();
}
    


    $user_name = $_POST['user_name'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $email = $_POST['email'];
    $role = $_POST['role'];

    $sql = "INSERT INTO users (user_name, password, email, role) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $user_name, $password, $email, $role);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Etudiant ajouter avec success!";
        header("Location: ../page/admin_ajou_etu.php");
        exit();
    } else {
        $_SESSION['error'] = "Failed to add author.";
        header("Location: ../page/admin_ajou_etu.php");
    }

    $stmt->close();
    $conn->close();
}
if (isset($_POST['annuler'])){
    header("Location: ../page/admin_ajou_etu.php");
    exit();
}
