<?php
session_start();
include '../includes/db_connect.php';

if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}

if (isset($_POST['delete'])) {
    $cat_id = $_POST['cat_id'];

    $sql = "DELETE FROM catégories WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $cat_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Catégorie éffacer de la base de donnée !!";
        header("Location: ../page/admin_list_cat.php");
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }

    $stmt->close();
}

$conn->close();

