<?php
session_start();
include 'db_connect.php';

// Vérifier si l'utilisateur est connecté et s'il est administrateur
if (!isset($_SESSION['user_name']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../page/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['ajouter'])) {
        $title = $_POST['title'];
        $description = $_POST['description'];
        $categorie_id = $_POST['categorie_id'];
        $link = $_POST['link'];
        $auteur_id = $_POST['auteur_id'];

        // Préparation de la requête SQL pour insérer le livre
        $sql = "INSERT INTO livres (title, description, categorie_id, link, auteur_id) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssisi", $title, $description, $categorie_id, $link, $auteur_id);

        if ($stmt->execute()) {
            // Redirection vers la page de gestion des livres avec un message de succès
            $_SESSION['message'] = "livre ajouter avec success!";
            header("Location: ../page/admin_ajou_liv.php");
        } else {
            // Redirection vers la page d'ajout de livre avec un message d'erreur
            $_SESSION['error'] = "Erreur le livre n'as pas été ajouter veillez réessailer.";
            header("Location: ../page/admin_ajou_liv.php");
        }

        $stmt->close();
    } elseif (isset($_POST['annuler'])) {
        // Redirection vers la page de gestion des livres sans effectuer d'action
        header("Location: ../page/admin_ajou_liv.php");
    }
}
$conn->close();

