<?php
require"includes/db_connect.php";
header("Location: page/acceuil.php");
exit();

