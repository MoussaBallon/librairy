<?php
session_start();
include '../includes/db_connect.php';

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_name'])) {
    header("Location: ../login.php");
    exit();
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>bibliothèque</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
</head>
<body>
  <div id="hero1">
          <nav >
              <ul class="nav justify-content-center pt-3 ">>
                  <li class="nav-item">
                    <a class="nav-link" href="acceuil.php"><h6>Acceuil</h6></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="about.php"><h6> <span>à</span> propos</h6></a>
                  </li>
                </ul>
            </nav>
            <div class="container">
          <div class="row">
            <div class="col-1">
                  <img src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" style="width:100px; height:100px; border-radius: 100px;" alt=""> 
            </div>
            <div class="col-2"></div>
              <div class="col-8">
                <h1 style="margin-left: 100px; margin-top: 10px; ; font-family:pop; color: white; opacity:0;
                  transform: translateX(-100px);
                  animation: apparition 1.2s  0.9s ease-out forwards;" >
                    <span id="slt">
                        <img src="../medias/slt.png" width="50" height="50" alt="">
                      </span>
                    Bienvenue, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!
                </h1>
              </div>
              <div class="col-1 mt-4">
              <a href="../includes/logout.php"> <button class="btn btn-primary ">Deconnexion</button></a>
              </div>
          </div>
        </div>
            <span id="grc" class="">
              <img src="../medias/garçon lit.png" width="150" height="150" alt="">
            </span> 
            <div id="tableau2" style="margin-top: -110px;">
                
              <div class="container" id="navi">
                <div class="row">
                  <div class="col-12">
                    <p class="text-center" style="font-size: 20px; font-family: pop; font-weight: bold;"> <img src="../medias/book.png" width="50" height="50" alt=""> Bibliothèque</p>
                  </div>
                </div>
              </div>
            
              <div id="menu">
                <h1 class="text-center  text-white" style="font-family: pop; font-weight: bold; font-size: 20px; padding-top: 10px; text-decoration: underline;">Menu</h1>
                <p class="text-center text-white pt-5 fw-bold">

                <?php

        $sql = "SELECT id, nom, link FROM catégories";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<ul>
                        <li>
                          <a href='" . htmlspecialchars($row['link']) . "' style='color: white;' href='category.php?id=" . $row['id'] . "'>" . htmlspecialchars($row['nom']) . "</a>
                        </li>
                        </ul>";
            }
        } else {
            echo "<li>Aucune catégorie trouvée</li>";
        }

        $conn->close();
        ?>



                           <!--<select id="auteur" name="auteur_id" class="w-50">
                           // <?php
                            //       while ($row = $result_auteurs->fetch_assoc()) {
                              //    echo "<option value='" . $row['id'] . "'>" . $row['nom'] . "</option>";
                                //    }
                              ?>
                            </select>-->





                  <!--<span class="sou" style="text-decoration: underline;"><a href="dev.php" style="color: white;">Developpement web</a></span> <br> <br>
                  <span class="sou"><a href="marketing.php" style="color: white;">Marqueting</a></span> <br><br>
                  <span class="sou"><a href="science.php" style="color: white;">Sciences Sociales</a></span><br><br>
                  <span class="sou"><a href="reseau.php" style="color: white;">Réseaux info & Télécommunication</a></span><br><br>
                  <span class="sou"><a href="logistic.php" style="color: white;">logistique & transport</a></span><br><br>
                  <span class="sou"><a href="diver.php" style="color: white;">Divers</a></span>--> 
                </p>
              </div>
            
            <span id="navi1" >
              <h6 style="margin-left: 400px; margin-top: -420px;">
                <ul >
                  <li>
                    <a href="#">Catégories</a>
                  </li>
                  <li>
                    <a href="auteur.php">Auteurs</a>
                  </li>
                  <li>
                    <a href="livre.php">livres</a>
                  </li>
                </ul>
              </h6>
            </span>
          <div class="justify-content-center" style="width: 50%; margin-left: 400px; margin-top: 50px;">
            <p  style="font-size: 20px; font-family: pop; font-weight: bold; color: red;">"Sélectionnez la catégorie de livre qui vous <br> intéresse dans Menu"</p>
          </div>
              
              <!-- Ajoutez plus de contenu ici si nécessaire -->
          </div>
                  
              </div>
        


      </div>
  </div>
</body>
</html>