<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceuil</title>
    <script src="script.js" defer></script>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
</head>
<body>
   <div id="hero1">
        <nav >
            <ul class="nav justify-content-center pt-3 ">
                <li class="nav-brand">
                    <img src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" alt=""> 
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="acceuil.php"><h6>  Acceuil</h6></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php"><h6> <span>à</span> propos</h6></a>
                </li>
            </ul>
        </nav>
        <span id="grc" class="">
            <img src="../medias/garçon lit.png" width="150" height="150" alt="">
          </span> 
        <div class="container">
            <div class="row">
                <div class="d-flex justify-content-center ">
                   <div>
                    <img src="../medias/Zak.jpg" width="200px" height="200px" style="border-radius: 100px;" alt="">
                   </div>
                   <div>
                        <h2 style="font-weight: bold; font-family: pop; color: rgb(247, 228, 193);">Zak Ruvalcaba</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="justify-content-center" style="background-color: rgba(0, 0, 0, 0.438);">
                <p style="font-weight: bold; font-family: pop; color: rgb(247, 228, 193); padding: 20px;">
                    Zak Ruvalcaba est un développeur de logiciels, auteur et formateur renommé, spécialisé dans les technologies web et le développement de logiciels. Il est particulièrement reconnu pour ses contributions à l'enseignement des technologies de développement web.

                    **Biographie succincte :**
                    
                    - **Nom complet :** Zak Ruvalcaba
                    - **Profession :** Développeur de logiciels, auteur, formateur
                    
                    **Carrière et Contributions :**
                    
                    1. **Enseignement et Formation :** Zak Ruvalcaba a enseigné dans plusieurs institutions académiques et a conçu des programmes de formation pour divers aspects du développement web, incluant HTML, CSS, JavaScript, ASP.NET, et d'autres technologies. Il a aidé de nombreux étudiants et professionnels à acquérir des compétences essentielles en développement web.
                    
                    2. **Ouvrages pédagogiques :** Il est l'auteur de plusieurs livres sur le développement web, souvent publiés en collaboration avec Mike Murach. Ses livres sont connus pour leur clarté, leur approche didactique et leur pertinence pratique. Parmi ses œuvres notables, on trouve des manuels sur HTML5, CSS3, JavaScript, et ASP.NET.
                    
                    3. **Développement de logiciels :** En tant que développeur, Zak Ruvalcaba a travaillé sur divers projets, mettant en œuvre les dernières technologies web et mobiles. Son expertise couvre une large gamme de compétences techniques, de la conception de l'interface utilisateur au développement back-end.
                    
                    4. **Consulting et Conférences :** En plus de ses activités d'enseignement et d'écriture, Zak Ruvalcaba a travaillé comme consultant pour aider des entreprises à améliorer leurs capacités de développement web. Il participe également à des conférences et des séminaires, partageant ses connaissances et son expérience avec la communauté des développeurs.
                    
                    **Philosophie :**
                    
                    Zak Ruvalcaba prône une approche pratique et axée sur les résultats pour l'apprentissage du développement web. Il met l'accent sur l'acquisition de compétences pratiques que les étudiants peuvent appliquer directement dans leurs projets professionnels. Son approche pédagogique vise à rendre les concepts techniques accessibles et compréhensibles pour tous les niveaux d'expérience.
                    
                    Grâce à ses contributions en tant qu'enseignant, auteur et développeur, Zak Ruvalcaba a joué un rôle crucial dans la formation de nombreux développeurs web et dans la promotion des meilleures pratiques dans le domaine du développement de logiciels.
                </p>
            </div>
        </div>

   </div>
  









   <script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>