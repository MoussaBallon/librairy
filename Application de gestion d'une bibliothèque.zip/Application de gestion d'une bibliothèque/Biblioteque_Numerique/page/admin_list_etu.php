<?php
session_start();
include '../includes/db_connect.php';

// Vérifier si l'utilisateur est connecté et s'il est administrateur
if (!isset($_SESSION['user_name']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Le reste de votre code d'administration
$sql = "SELECT users.id, users.user_name, users.email, users.role 
        FROM users";
$result = $conn->query($sql);
?>


<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
</head>
<body>
  <div id="hero1">
          <nav >
              <ul class="nav justify-content-center pt-3 ">
                  <li class="nav-item">
                    <a class="nav-link" href="acceuil.php"><h6>Acceuil</h6></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="about.php"><h6> <span>à</span> propos</h6></a>
                  </li>
                </ul>
            </nav>
            <div class="container">
          <div class="row">
            <div class="col-1">
                  <img src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" style="width:100px; height:100px; border-radius: 100px;" alt=""> 
            </div>
            <div class="col-2"></div>
              <div class="col-8">
                <h1 style="margin-left: 100px; margin-top: 10px; ; font-family:pop; color: white; opacity:0;
                  transform: translateX(-100px);
                  animation: apparition 1.2s  0.9s ease-out forwards;" >
                    <span id="slt">
                        <img src="../medias/slt.png" width="50" height="50" alt="">
                      </span>
                    Bienvenue monsieur, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!
                </h1>
              </div>
              <div class="col-1 mt-4">
              <a href="../includes/logout.php"> <button class="btn btn-primary ">Deconnexion</button></a>
              </div>
          </div>
        </div>
            <div id="tableau2" style="margin-top: 20px;">
                
              <div class="container" id="navi">
                <div class="row">
                  <div class="col-12">
                    <p class="text-center" style="font-size: 20px; font-family: pop; font-weight: bold;"> <img src="../medias/book.png" width="50" height="50" alt=""> Bibliothèque</p>
                  </div>
                </div>
              </div>  
              <div class="d-flex">
              <div id="menu">
                <p style="color: white; font-family:pop; font-size:30px; text-align: center; text-decoration-line: underline">
                  Menu
                </p>
                <ul style="list-style: none;">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" style="color:white; font-size:30px; position: relarelative; transform: translateX(-40px); " data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"> <img src="../medias/people.svg" width="50" height="40" alt="">Auteurs</a><br>
                        <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="admin_list_aut.php"> <img src="../medias/list-columns.svg" alt=""> Liste</a></li><br>
                        <li><a class="dropdown-item" href="admin_ajou_aut.php"> <img src="../medias/file-earmark-plus.svg" alt=""> Ajouter</a></li><br>
                        
                        </ul>
                    </li>
                </ul>
                <ul style="list-style: none;">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" style="color:white; font-size:30px; transform: translateX(-50px);" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"> <img src="../medias/list-columns.svg" width="30" height="30" alt=""> Catégories</a><br>
                        <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="admin_list_cat.php"> <img src="../medias/list-columns.svg" alt=""> Liste</a></li><br>
                        <li><a class="dropdown-item" href="admin_ajou_cat.php"> <img src="../medias/file-earmark-plus.svg" alt=""> Ajouter</a></li><br>
                        
                      
                        </ul>
                    </li>
                </ul>
                <ul style="list-style: none;">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" style="color:white; font-size:30px; position: relarelative; transform: translateX(-55px);" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"> <img src="../medias/book.png" width="50" height="50" alt=""> Ouvrages</a><br>
                        <ul class="dropdown-menu">
                          <li><a class="dropdown-item" href="admin_list_liv.php"> <img src="../medias/list-columns.svg" alt=""> Liste</a></li><br>
                          <li><a class="dropdown-item" href="admin_ajou_liv.php"> <img src="../medias/file-earmark-plus.svg" alt=""> Ajouter</a></li><br>
                          
                      
                        </ul>
                    </li>
                </ul>
                <ul style="list-style: none">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" style="color:white; font-size:30px; position: relarelative; transform: translateX(-40px); " data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"> <img src="../medias/people.svg" width="50" height="40" alt="">Etudiants</a><br>
                        <ul class="dropdown-menu">
                          <li><a class="dropdown-item" href="admin_list_etu.php"> <img src="../medias/person-lines-fill.svg" alt=""> Liste</a></li><br>
                          <li><a class="dropdown-item" href="admin_ajou_etu.php"> <img src="../medias/person-add.svg" alt=""> Ajouter</a></li><br>
                          
                        </ul>
                    </li>
                </ul>
            </div>
                 <div class="container pt-2">
                    <div class="recherche_area bg-secondary mb-2" style="height:150px; padding:10px">
                        <p class="text-center text-white fs-5">
                          Rechercher un Etudiant <img src="../medias/cher.svg" width="15" height="15" alt="">
                        </p>
                        <form method="GET" action="../includes/search_students.php" style="background: none;">
                          <input type="text" name="search" style="border-radius:20px" placeholder="Rechercher un étudiant" autocomplete="off" required>
                          <button class="btn btn-warning" style="width:100px; border-radius:100px;" type="submit">Rechercher</button>
                      </form>
                            
                    </div>
                    <div class="scroll-container ms-5 " style="height:250px; border:5px solid red;"> 
                    <div id="search_results"></div>
                    <table id="students_table">
                    <h4>Liste des livres    
                       <?php
                            if (isset($_SESSION['mes'])) {
                                echo "<p style='color:green; font-size:18px; text-align:center;'>" . $_SESSION['mes'] . "</p>";
                                unset($_SESSION['mes']);
                            }
                            if (isset($_SESSION['error'])) {
                                echo "<p style='color:red;'>" . $_SESSION['error'] . "</p>";
                                unset($_SESSION['error']);
                            }
                            ?></h4>
                      <table>
                          <thead>
                              <tr>
                                  <th>Nom</th>
                                  <th>Email</th>
                                  <th>role</th>
                                  <th>Action</th>
                              </tr>
                          </thead>
                          <tbody>
                              <?php
                              if ($result->num_rows > 0) {
                                  while($row = $result->fetch_assoc()) {
                                      echo "<tr>
                                      <td>" . $row['user_name'] . "</td>
                                      <td>" . $row['email'] . "</td>
                                      <td>" . $row['role'] . "</td>
                                      <td class='action-buttons'>
                                           <a href='../page/admin_modif_etu.php?id=" . $row['id'] . "' style='background:green; padding:10px; margin-bottum:0;'>
                                            <img src='../medias/pen.svg' alt='Modifier' title='Modifier'>
                                          </a>
                                        <form action='../Includes/trait_supp_etu.php' method='POST' style='display:inline; transform: translateX( 200px);  background:none;'>
                                              <input type='hidden' name='user_id' value='" . $row['id'] . "'>
                                              <button type='submit' name='delete' class='delete-button btn-danger'>
                                                  <img src='../medias/trash.svg' alt='Delete' title='Delete'>
                                              </button>
                                            </form>
                                       </td>

                                        </tr>";
                                  }
                              } else {
                                  echo "<tr><td>Aucun livre trouver !</td></tr>";
                              }
                              ?>
                              
                          </tbody>
                        </table>
                    </div>
                 </div> 


              </div>
            
              
              <!-- Ajoutez plus de contenu ici si nécessaire -->
          </div>
                  
              </div>
        


      </div>
  </div>
</body>
</html>
