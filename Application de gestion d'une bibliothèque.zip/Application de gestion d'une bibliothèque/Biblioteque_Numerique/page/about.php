<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceuil</title>
    <script src="script.js" defer></script>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
</head>
<body>
   <div id="hero1">
      <nav >
        <ul class="nav justify-content-center  ">
            <li class="nav-brand">
                <img src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" alt=""> 
            </li>
            <li class="nav-item">
              <a class="nav-link" href="acceuil.php"><h6>  Acceuil</h6></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.php"><h6> <span>à</span> propos</h6></a>
            </li>
          </ul>
      </nav>
      <div class="container" style="background-color: rgba(0, 0, 0, 0.555); border-radius: 15px;">
        <p class="text-rigth" style="color: white; padding: 10px; justify-content: center;" >
              Notre Histoire <br><br>

    Le projet de bibliothèque numérique de l'annexe de l'institut ISTAG à Djélibougou est né d'un constat simple : l'absence de ressources littéraires disponibles pour les étudiants sur place. Afin de combler cette lacune, nous avons entrepris de créer une plateforme accessible et riche en contenu pour tous les passionnés de lecture et les étudiants avides de connaissances. <br><br>

    Notre Mission <br>

    Notre mission est de fournir un accès facile et gratuit à une variété de livres et de ressources littéraires pour les étudiants et le grand public. Nous nous engageons à offrir une expérience de lecture agréable et enrichissante, permettant à chacun d'explorer différentes catégories de livres, de consulter des résumés et de télécharger les ouvrages de leur choix. <br><br>

    Notre Bibliothèque <br>

    La bibliothèque numérique offre une large gamme de catégories de livres, allant de la littérature classique aux ouvrages spécialisés. Chaque livre est accompagné d'un résumé pour aider les utilisateurs à choisir ce qui les intéresse. En plus de cela, une page dédiée aux auteurs permet aux étudiants et aux lecteurs de découvrir plus d'informations sur les écrivains et leurs œuvres. <br><br>

    Accessibilité <br>

    Le site est conçu pour être statique, sans base de données, ce qui garantit une navigation rapide et fluide. De plus, il est accessible à tous sans besoin d'authentification, rendant la connaissance et la culture littéraire disponibles à un public large et varié. <br><br>

    Pourquoi Nous Choisir <br>

    Nous croyons fermement que l'accès à la connaissance ne doit pas être limité. En choisissant notre bibliothèque numérique, vous avez accès à une ressource précieuse qui vous permet d'explorer et de découvrir des livres en toute liberté. Nous sommes dédiés à enrichir l'expérience d'apprentissage des étudiants et à promouvoir la lecture auprès de la communauté.


        </p>
      </div>
   </div>


   <footer>
    <div class="container">
     <div>
      <h4 class="text-center" style="color: white; font-family: pop; text-decoration-line: underline;">ISTAG-ESPIM</h4>
     </div>
     <div class="row">
      <div class="col-3"></div>
      <div class="col-3">
        <p style="color: white; font-family: pop;">
          Direction Générale : <br> Baco Djicoroni ACI,<br>Rue 822, Porte 1780 <br><br>
          Annexe : <br> Djélibougou près du L.Kodonso 
        </p>
      </div>
      <div class="col-1"></div>
      <div class="col-3">
        <p style="color: white; font-family: pop;">
          Tel : <br> +223 20 74 11 37 / 74 47 57 33 <br> 60 12 50 56 / 90 55 55 82 <br><br>
          Email: <br> <a style="color: white;" href="mailto:istag@istagmali.com?subject=Sujet%20du%20mail&body=Contenu%20du%20mail">istag@istagmali.com</a> <br>
          <a style="color: white;" href="mailto:istag.mali@yahoo.com?subject=Sujet%20du%20mail&body=Contenu%20du%20mail">istag.mali@yahoo.com</a> 

        </p>
      </div>
     </div>
    </div>
   </footer>
  









   <script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>