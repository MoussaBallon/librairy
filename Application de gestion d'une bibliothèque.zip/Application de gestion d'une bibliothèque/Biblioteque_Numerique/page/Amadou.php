<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceuil</title>
    <script src="script.js" defer></script>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
</head>
<body>
   <div id="hero1">
        <nav >
            <ul class="nav justify-content-center pt-3 ">
                <li class="nav-brand">
                    <img src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" alt=""> 
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="acceuil.php"><h6>  Acceuil</h6></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php"><h6> <span>à</span> propos</h6></a>
                </li>
            </ul>
        </nav>
        <span id="grc" class="">
            <img src="../medias/garçon lit.png" width="150" height="150" alt="">
          </span> 
        <div class="container">
            <div class="row">
                <div class="d-flex justify-content-center">
                   <div>
                    <img src="../medias/Amadou.jpg" width="200px" height="200px" style="border-radius: 100px;" alt="">
                   </div>
                   <div>
                        <h2 style="font-weight: bold; font-family: pop; color: rgb(247, 228, 193);">Amadou Hampathé Bah</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="justify-content-center" style="background-color: rgba(0, 0, 0, 0.438);">
                <p style="font-weight: bold; font-family: pop; color: rgb(247, 228, 193); padding: 20px;">
                    Amadou Hampaté Bâ (1901-1991) était un éminent écrivain et ethnologue malien. Né à Bandiagara, dans l'actuel Mali, il a consacré sa vie à la préservation et à la transmission des traditions orales africaines. <br> 

 <br> Élevé dans une famille peule, il a étudié dans des écoles coraniques et françaises. Après ses études, il a travaillé pour l'administration coloniale française avant de se tourner vers la recherche et l'écriture. Il a rejoint l'Institut français d'Afrique noire (IFAN) à Dakar, où il a mené des recherches approfondies sur les cultures et les traditions de l'Afrique de l'Ouest. <br>

 <br>  Amadou Hampaté Bâ est surtout connu pour sa célèbre phrase : "En Afrique, un vieillard qui meurt est une bibliothèque qui brûle", soulignant l'importance de la tradition orale et de la sagesse des anciens. <br> Parmi ses œuvres les plus notables figurent "L'Étrange Destin de Wangrin" et "Amkoullel l'enfant peul", où il raconte ses mémoires et offre un aperçu précieux de la vie africaine traditionnelle.

Il a également joué un rôle crucial dans la promotion des langues africaines et a été membre du Conseil exécutif de l'UNESCO. Grâce à ses efforts inlassables, il a contribué à la préservation de la richesse culturelle de l'Afrique pour les générations futures.
                </p>
            </div>
        </div>

   </div>
  









   <script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>