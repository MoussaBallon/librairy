<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceuil</title>
    <script src="script.js" defer></script>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
</head>
<body>
   <div id="hero1">
        <nav >
            <ul class="nav justify-content-center pt-3 ">
                <li class="nav-brand">
                    <img src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" alt=""> 
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="acceuil.php"><h6>  Acceuil</h6></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php"><h6> <span>à</span> propos</h6></a>
                </li>
            </ul>
        </nav>
        <span id="grc" class="">
            <img src="../medias/garçon lit.png" width="150" height="150" alt="">
          </span> 
        <div class="container">
            <div class="row">
                <div class="d-flex justify-content-center">
                   <div>
                    <img src="../medias/SeydouB.jpg" width="200px" height="200px" style="border-radius: 100px;" alt="">
                   </div>
                   <div>
                        <h2 style="font-weight: bold; font-family: pop; color: rgb(247, 228, 193);">Sédou Badien Koyaté</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="justify-content-center" style="background-color: rgba(0, 0, 0, 0.438);">
                <p style="font-weight: bold; font-family: pop; color: rgb(247, 228, 193); padding: 20px;">
                    Seydou Badian Kouyaté (1928-2018) était un écrivain et homme politique malien. Né à Bamako, alors partie du Soudan français, il a fait ses études secondaires à Bamako avant de poursuivre des études de médecine en France, où il a obtenu son diplôme de docteur en médecine en 1956.

                    De retour au Mali, Seydou Badian a rapidement pris une place importante dans la politique de son pays nouvellement indépendant. Il a été nommé ministre de l'Économie rurale et du Plan sous la présidence de Modibo Keïta. Plus tard, il a été ministre du Développement et de la Coopération internationale. Son engagement politique a été marqué par sa volonté de développer le Mali en s'appuyant sur ses propres ressources et en valorisant les cultures locales.
                    
                    En tant qu'écrivain, Seydou Badian est surtout connu pour son roman "Sous l'orage" (1957), qui traite des conflits entre les valeurs traditionnelles africaines et les influences occidentales. Ses autres œuvres importantes incluent "Le Sang des masques" (1976) et "Noces sacrées" (1977). Ses écrits sont souvent centrés sur la lutte pour l'identité africaine et la résistance à la domination coloniale.
                    
                    En plus de ses contributions littéraires, Seydou Badian était également un fervent défenseur de l'unité africaine et a travaillé à promouvoir l'idée d'une Afrique indépendante et prospère. Sa vie et son œuvre continuent d'inspirer de nombreuses personnes à travers le continent africain et au-delà.
                </p>
            </div>
        </div>

   </div>
  









   <script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>