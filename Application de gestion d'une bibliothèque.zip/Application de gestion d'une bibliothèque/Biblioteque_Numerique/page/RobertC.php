<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceuil</title>
    <script src="script.js" defer></script>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
</head>
<body>
   <div id="hero1">
        <nav >
            <ul class="nav justify-content-center pt-3 ">
                <li class="nav-brand">
                    <img src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" alt=""> 
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="acceuil.php"><h6>  Acceuil</h6></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php"><h6> <span>à</span> propos</h6></a>
                </li>
            </ul>
        </nav>
        <span id="grc" class="">
            <img src="../medias/garçon lit.png" width="150" height="150" alt="">
          </span> 
        <div class="container">
            <div class="row">
                <div class="d-flex justify-content-center ">
                   <div>
                    <img src="../medias/ROberC.jpg" width="200px" height="200px" style="border-radius: 100px;" alt="">
                   </div>
                   <div>
                        <h2 style="font-weight: bold; font-family: pop; color: rgb(247, 228, 193);">Robert.C MArtine</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="justify-content-center" style="background-color: rgba(0, 0, 0, 0.438);">
                <p style="font-weight: bold; font-family: pop; color: rgb(247, 228, 193); padding: 20px;">
                    Robert C. Martin, souvent connu sous le nom de "Uncle Bob", est un développeur de logiciels renommé, consultant et auteur. Il est particulièrement célèbre pour ses contributions dans le domaine de l'ingénierie logicielle et pour avoir popularisé des concepts importants tels que les principes SOLID de conception orientée objet.

                    **Biographie succincte :**
                    
                    - **Nom complet :** Robert Cecil Martin
                    - **Surnom :** Uncle Bob
                    - **Date de naissance :** 5 décembre 1952
                    - **Profession :** Développeur de logiciels, consultant, auteur
                    
                    **Carrière :**
                    
                    Robert C. Martin a commencé sa carrière dans le développement de logiciels dans les années 1970. Il a fondé Object Mentor, une société de conseil en développement de logiciels, qui a aidé de nombreuses entreprises à améliorer leurs processus de développement et à adopter des pratiques de programmation plus efficaces.
                    
                    **Contributions :**
                    
                    1. **Principes SOLID :** Martin est largement reconnu pour avoir formulé et popularisé les principes SOLID, un ensemble de cinq principes de conception orientée objet qui aident les développeurs à créer des logiciels plus robustes et maintenables.
                       
                    2. **Méthodes Agiles :** Il est un des signataires originaux du Manifeste Agile, un document fondamental qui a jeté les bases des méthodologies de développement agile. Martin a également écrit plusieurs livres sur les pratiques agiles, dont "Agile Software Development, Principles, Patterns, and Practices".
                       
                    3. **Livres et Publications :** Il a écrit plusieurs livres influents dans le domaine du développement logiciel, notamment "Clean Code: A Handbook of Agile Software Craftsmanship" et "The Clean Coder: A Code of Conduct for Professional Programmers". Ces ouvrages sont considérés comme des références pour les développeurs cherchant à améliorer la qualité de leur code et leur professionnalisme.
                    
                    **Philosophie :**
                    
                    Robert C. Martin prône une approche rigoureuse et disciplinée du développement logiciel, mettant l'accent sur la qualité du code, la simplicité, et la pratique continue. Il croit fermement que les développeurs doivent adopter une attitude professionnelle et éthique dans leur travail, en adhérant à des standards élevés de qualité et de responsabilité.
                    
                    En tant qu'orateur et formateur, Martin continue d'influencer la communauté des développeurs de logiciels à travers ses conférences, ateliers et publications, inspirant de nombreuses personnes à améliorer leurs compétences et à adopter des pratiques de développement plus efficaces.
                </p>
            </div>
        </div>

   </div>
  









   <script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>