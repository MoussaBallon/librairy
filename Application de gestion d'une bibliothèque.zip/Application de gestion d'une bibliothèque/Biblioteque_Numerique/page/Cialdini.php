<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceuil</title>
    <script src="script.js" defer></script>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
</head>
<body>
   <div id="hero1">
        <nav >
            <ul class="nav justify-content-center pt-3 ">
                <li class="nav-brand">
                    <img src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" alt=""> 
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="cceuil.php"><h6>  Acceuil</h6></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php"><h6> <span>à</span> propos</h6></a>
                </li>
            </ul>
        </nav>
        <span id="grc" class="">
            <img src="../medias/garçon lit.png" width="150" height="150" alt="">
          </span> 
        <div class="container">
            <div class="row">
                <div class="d-flex justify-content-center">
                   <div>
                    <img src="../medias/Cialdini.jpg" width="200px" height="200px" style="border-radius: 100px;" alt="">
                   </div>
                   <div>
                        <h2 style="font-weight: bold; font-family: pop; color: rgb(247, 228, 193);">Robert Cialdini</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="justify-content-center" style="background-color: rgba(0, 0, 0, 0.438);">
                <p style="font-weight: bold; font-family: pop; color: rgb(247, 228, 193); padding: 20px;">
                    Robert Cialdini est un psychologue social américain et professeur émérite de psychologie et de marketing à l'Université d'État de l'Arizona. Il est mondialement reconnu pour ses travaux sur la psychologie de la persuasion et de l'influence sociale.

                    **Biographie succincte :**
                    
                    - **Nom complet :** Robert Beno Cialdini
                    - **Date de naissance :** 27 avril 1945
                    - **Profession :** Psychologue, auteur, conférencier
                    
                    **Carrière :**
                    
                    Cialdini a obtenu son doctorat en psychologie sociale de l'Université de Caroline du Nord à Chapel Hill et a effectué un stage postdoctoral à l'Université Columbia. Il a passé sa carrière universitaire à l'Université d'État de l'Arizona, où il a enseigné la psychologie et le marketing.
                    
                    **Contributions :**
                    
                    1. **Principes d'influence :** Cialdini est surtout connu pour son livre "Influence: The Psychology of Persuasion" (1984), qui présente six principes fondamentaux de l'influence : la réciprocité, l'engagement et la cohérence, la preuve sociale, l'autorité, la sympathie et la rareté. Ces principes expliquent comment et pourquoi les gens peuvent être influencés par les autres.
                    
                    2. **Travaux et recherches :** Ses recherches ont été largement citées et appliquées dans divers domaines, y compris le marketing, la vente, le management et la négociation. Ses travaux sont basés sur des expériences scientifiques rigoureuses et des observations pratiques, ce qui les rend très crédibles et applicables.
                    
                    3. **Publications et livres :** Outre "Influence", Cialdini a écrit plusieurs autres livres importants, dont "Pre-Suasion: A Revolutionary Way to Influence and Persuade" (2016), qui explore comment préparer le terrain pour rendre les messages de persuasion plus efficaces.
                    
                    4. **Conférences et formation :** En tant que conférencier et formateur, Cialdini a travaillé avec de nombreuses entreprises et organisations à travers le monde pour les aider à comprendre et à appliquer les principes de persuasion dans leurs pratiques commerciales et de communication.
                    
                    **Philosophie :**
                    
                    Robert Cialdini prône une approche éthique de la persuasion, soulignant que l'influence doit être utilisée de manière responsable et pour le bien de toutes les parties impliquées. Il met en garde contre l'utilisation abusive des techniques de persuasion, car elles peuvent conduire à une perte de confiance et de crédibilité à long terme.
                    
                    Grâce à ses contributions significatives, Cialdini a profondément influencé la manière dont la persuasion est comprise et pratiquée dans de nombreux domaines, faisant de lui une figure incontournable dans le domaine de la psychologie sociale et du marketing.
                </p>
            </div>
        </div>

   </div>
  









   <script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>