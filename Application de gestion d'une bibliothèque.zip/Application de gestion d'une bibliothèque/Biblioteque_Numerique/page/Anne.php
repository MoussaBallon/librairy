<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceuil</title>
    <script src="script.js" defer></script>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
</head>
<body>
   <div id="hero1">
        <nav >
            <ul class="nav justify-content-center pt-3 ">
                <li class="nav-brand">
                    <img src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" alt=""> 
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="acceuil.php"><h6>  Acceuil</h6></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php"><h6> <span>à</span> propos</h6></a>
                </li>
            </ul>
        </nav>
        <span id="grc" class="">
            <img src="../medias/garçon lit.png" width="150" height="150" alt="">
          </span> 
        <div class="container">
            <div class="row">
                <div class="d-flex justify-content-center">
                   <div>
                    <img src="../medias/Anne.jpg" width="200px" height="200px" style="border-radius: 100px;" alt="">
                   </div>
                   <div>
                        <h2 style="font-weight: bold; font-family: pop; color: rgb(247, 228, 193);">Anne Boehm</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="justify-content-center" style="background-color: rgba(0, 0, 0, 0.438);">
                <p style="font-weight: bold; font-family: pop; color: rgb(247, 228, 193); padding: 20px;">
                    Anne Boehm est une auteure et développeuse de logiciels reconnue pour ses contributions dans le domaine de l'éducation en programmation et en développement de logiciels. Elle est surtout connue pour ses ouvrages pédagogiques qui aident les débutants et les professionnels à maîtriser divers langages de programmation et technologies de développement.

                    **Biographie succincte :**
                    
                    - **Nom complet :** Anne Boehm
                    - **Profession :** Auteure, développeuse de logiciels, formatrice
                    
                    **Carrière et Contributions :**
                    
                    1. **Ouvrages pédagogiques :** Anne Boehm a coécrit plusieurs livres avec Mike Murach, un autre auteur renommé dans le domaine de la programmation. Leurs livres sont particulièrement appréciés pour leur clarté, leur approche pédagogique et leur pertinence pratique. Parmi ses œuvres les plus connues, on trouve des manuels sur des technologies comme C#, Visual Basic, ASP.NET et SQL Server.
                    
                    2. **Murach's Books:** Ses ouvrages sont publiés par Murach's Books, une maison d'édition réputée pour ses ressources éducatives en informatique. Les livres d'Anne Boehm sont largement utilisés dans les écoles, les collèges et les programmes de formation professionnelle pour enseigner la programmation et le développement de logiciels.
                    
                    3. **Approche pédagogique :** Les livres d'Anne Boehm sont connus pour leur style convivial et structuré, rendant l'apprentissage des concepts complexes plus accessible. Ils incluent souvent des exemples pratiques, des exercices et des explications détaillées pour aider les lecteurs à comprendre et à appliquer les concepts de programmation.
                    
                    **Philosophie :**
                    
                    Anne Boehm croit fermement en l'importance de rendre la programmation accessible à tous, indépendamment de leur niveau d'expérience. Elle met l'accent sur une approche pratique de l'apprentissage, où les étudiants peuvent immédiatement appliquer ce qu'ils ont appris à travers des exercices et des projets concrets.
                    
                    Grâce à ses contributions significatives dans le domaine de l'éducation en programmation, Anne Boehm a aidé de nombreux étudiants et professionnels à développer leurs compétences en développement de logiciels, faisant d'elle une figure respectée et influente dans le domaine de la formation en informatique.
                </p>
            </div>
        </div>

   </div>
  









   <script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>