<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceuil</title>
    <script src="script.js" defer></script>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
</head>
<body>
   <div id="hero1">
   <nav >
    <ul class="nav justify-content-center pt-3 ">
        <li class="nav-brand">
            <img src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" alt=""> 
        </li>
        <li class="nav-item">
          <a class="nav-link" href="Acceuil.html"><h6>  Acceuil</h6></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.html"><h6> <span>à</span> propos</h6></a>
        </li>
      </ul>
   </nav>

   <div>
    <div class="container" style="margin-left: 250px;">
        <div class="row">
            <div class="col-4">
                <img src="../medias/dev1.jpg" width="300px" height="450px" style="border-radius: 15px;"  alt="">
            </div>
            <div class="col-6" style="background-color: rgba(0, 0, 0, 0.295); border-radius: 15px; height: 250px; margin-top: 100px;">
             <div class="container">
                <div class="row">
                    <div class="col-3">
                        <p style="color: white; font-family: pop;">Titre: <br>AppWeb <br> <br>
                        Auteur: <br> Robert C. Martin </p>
                    </div>
                    <div class="col-3">
                        <p  style="color: white; font-family: pop;">Date de publication : 1er août 2008 <br> <br>
                            ISBN : 978-0132350884</p>
                    </div>
                </div>
             </div>
        </div>
    </div>
    <div class="mt-5">
        <a target="_blank" href="../medias/ApllicationWeb.pdf"><button class="btn btn-danger ">Telechager</button></a>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-8"  style="background-color: rgba(0, 0, 0, 0.384); border-radius: 15px; margin-top: 100px;">
                <p class="p-3" style="color: white; font-family: pop;">
                    Description : <br>
                    "Clean Code: A Handbook of Agile Software Craftsmanship" est un guide pratique pour écrire du code propre, maintenable et évolutif. Robert C. Martin partage ses décennies d'expérience et propose des principes, des pratiques et des astuces pour éviter les pièges courants du développement logiciel. Le livre est divisé en trois parties :
                    
                    Les principes et les meilleures pratiques du code propre : Cette partie couvre les techniques essentielles pour écrire du code lisible et bien structuré.
                    Les études de cas : Martin propose plusieurs études de cas de code "sale" qu'il refactorise en code propre, illustrant ainsi les concepts présentés dans la première partie.
                    Les heuristiques et les "smells" de code : Cette partie offre une liste de conseils pratiques et de mauvaises pratiques à éviter pour maintenir la propreté du code.
                    "Clean Code" est largement apprécié pour sa clarté, ses exemples concrets et son approche pragmatique, faisant de lui une ressource précieuse pour les développeurs de tous niveaux.
                </p>
            </div>
        </div>
    </div>
   </div>


 
   </div>
  









   <script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>