<?php
session_start();
include '../includes/db_connect.php';

// Vérifier si l'utilisateur est connecté et s'il est administrateur
if (!isset($_SESSION['user_name']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Le reste de votre code d'administration
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
</head>
<body>
  <div id="hero1">
          <nav >
              <ul class="nav justify-content-center pt-3 ">
                  <li class="nav-brand">
                      <img src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" alt=""> 
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="acceuil.php"><h6>Acceuil</h6></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="about.php"><h6> <span>à</span> propos</h6></a>
                  </li>
                </ul>
            </nav>
            <div id="tableau2" style="margin-top: 20px;">
                
              <div class="container" id="navi">
                <div class="row">
                  <div class="col-12">
                    <p class="text-center" style="font-size: 20px; font-family: pop; font-weight: bold;"> <img src="../medias/book.png" width="50" height="50" alt=""> Bibliothèque</p>
                  </div>
                </div>
              </div>  
              <div class="d-flex">
              <div id="menu">
                <p style="color: white; font-family:pop; font-size:30px; text-align: center; text-decoration-line: underline">
                  Menu
                </p>
                <ul style="list-style: none;">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" style="color:white; font-size:30px;" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">Ouvrages</a><br>
                        <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="admin_list_liv.php"> <img src="../medias/list-columns.svg" alt=""> Liste</a></li><br>
                        <li><a class="dropdown-item" href="admin_ajou_liv.php"> <img src="../medias/file-earmark-plus.svg" alt=""> Ajouter</a></li><br>
                        <li><a class="dropdown-item" href="admin_modif_liv.php"> <img src="../medias/pen.svg" alt=""> Modifier</a></li><br>
                        <li><a class="dropdown-item" href="admin_supp_liv.php"> <img src="../medias/file-earmark-x.svg" alt=""> Supprimer</a></li>
                        </ul>
                    </li>
                </ul>
                <ul style="list-style: none;">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" style="color:white; font-size:30px;" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">catégories</a><br>
                        <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="admin_list_cat.php"> <img src="../medias/list-columns.svg" alt=""> Liste</a></li><br>
                        <li><a class="dropdown-item" href="admin_ajou_cat.php"> <img src="../medias/file-earmark-plus.svg" alt=""> Ajouter</a></li><br>
                        <li><a class="dropdown-item" href="admin_modif_cat.php"> <img src="../medias/pen.svg" alt=""> Modifier</a></li><br>
                        <li><a class="dropdown-item" href="admin_supp_cat.php"> <img src="../medias/file-earmark-x.svg" alt=""> Supprimer</a></li>
                        </ul>
                    </li>
                </ul>
                <ul style="list-style: none;">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" style="color:white; font-size:30px;" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">Auteurs</a><br>
                        <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="admin_list_aut.php"> <img src="../medias/list-columns.svg" alt=""> Liste</a></li><br>
                        <li><a class="dropdown-item" href="admin_ajou_aut.php"> <img src="../medias/file-earmark-plus.svg" alt=""> Ajouter</a></li><br>
                        <li><a class="dropdown-item" href="admin_modif_aut.php"> <img src="../medias/pen.svg" alt=""> Modifier</a></li><br>
                        <li><a class="dropdown-item" href="admin_supp_aut.php"> <img src="../medias/file-earmark-x.svg" alt=""> Supprimer</a></li>
                        </ul>
                    </li>
                </ul>
                <ul style="list-style: none">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" style="color:white; font-size:30px;" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">Etudiants</a><br>
                        <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="admin_list_etu.php"> <img src="../medias/person-lines-fill.svg" alt=""> Liste</a></li><br>
                        <li><a class="dropdown-item" href="admin_ajou_etu.php"> <img src="../medias/person-add.svg" alt=""> Ajouter</a></li><br>
                        <li><a class="dropdown-item" href="admin_modif_liv.php"> <img src="../medias/pen.svg" alt=""> Modifier</a></li><br>
                        <li><a class="dropdown-item" href="admin_supp_etu.php"> <img src="../medias/person-x.svg" alt=""> Supprimer</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
              </div>
            
              
              <!-- Ajoutez plus de contenu ici si nécessaire -->
          </div>
                  
              </div>
        


      </div>
  </div>
</body>
</html>
