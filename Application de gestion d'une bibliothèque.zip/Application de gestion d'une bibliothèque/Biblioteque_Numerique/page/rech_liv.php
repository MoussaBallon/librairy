<?php
session_start();
include '../includes/db_connect.php';

// Vérifier si l'utilisateur est connecté et s'il est administrateur
if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
  }
// Le reste de votre code d'administration
// Le reste de votre code d'administration
$sql = "SELECT livres.id, livres.Title, auteurs.nom AS Auteur, catégories.nom AS Catégorie, livres.link, livres.Description
        FROM livres
        JOIN auteurs ON livres.auteur_id = auteurs.id
        JOIN catégories ON livres.categorie_id = catégories.id";
$result = $conn->query($sql);

?>


<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
</head>
<body>
  <div id="hero1">
          <nav >
              <ul class="nav justify-content-center pt-3 ">
                  <li class="nav-item">
                    <a class="nav-link" href="acceuil.php"><h6>Acceuil</h6></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="about.php"><h6> <span>à</span> propos</h6></a>
                  </li>
                </ul>
            </nav>
            <div class="container">
          <div class="row">
            <div class="col-1">
                  <img src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" style="width:100px; height:100px; border-radius: 100px;" alt=""> 
            </div>
            <div class="col-2"></div>
              <div class="col-8">
                <h1 style="margin-left: 100px; margin-top: 10px; ; font-family:pop; color: white; opacity:0;
                  transform: translateX(-100px);
                  animation: apparition 1.2s  0.9s ease-out forwards;" >
                    <span id="slt">
                        <img src="../medias/slt.png" width="50" height="50" alt="">
                      </span>
                    Bienvenue, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!
                </h1>
              </div>
              <div class="col-1 mt-4">
              <a href="../includes/logout.php"> <button class="btn btn-primary ">Deconnexion</button></a>
              </div>
          </div>
        </div>
            <div id="tableau2" style="margin-top: 20px;">
                
              <div class="container" id="navi">
                <div class="row">
                  <div class="col-12">
                    <p class="text-center" style="font-size: 20px; font-family: pop; font-weight: bold;"> <img src="../medias/book.png" width="50" height="50" alt=""> Bibliothèque</p>
                  </div>
                </div>
              </div>  
              <div class="d-flex">
              <div id="menu">
                <h1 class="text-center  text-white" style="font-family: pop; font-weight: bold; font-size: 20px; padding-top: 10px; text-decoration: underline;">Menu</h1>
                <p class="text-center text-white pt-5 fw-bold">

                <?php

        $sql = "SELECT id, nom, link FROM catégories";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<ul>
                        <li>
                          <a href='" . htmlspecialchars($row['link']) . "' style='color: white;' href='category.php?id=" . $row['id'] . "'>" . htmlspecialchars($row['nom']) . "</a>
                        </li>
                        </ul>";
            }
        } else {
            echo "<li>Aucune catégorie trouvée</li>";
        }

        $conn->close();
        ?>



                           <!--<select id="auteur" name="auteur_id" class="w-50">
                           // <?php
                            //       while ($row = $result_auteurs->fetch_assoc()) {
                              //    echo "<option value='" . $row['id'] . "'>" . $row['nom'] . "</option>";
                                //    }
                              ?>
                            </select>-->





                  <!--<span class="sou" style="text-decoration: underline;"><a href="dev.php" style="color: white;">Developpement web</a></span> <br> <br>
                  <span class="sou"><a href="marketing.php" style="color: white;">Marqueting</a></span> <br><br>
                  <span class="sou"><a href="science.php" style="color: white;">Sciences Sociales</a></span><br><br>
                  <span class="sou"><a href="reseau.php" style="color: white;">Réseaux info & Télécommunication</a></span><br><br>
                  <span class="sou"><a href="logistic.php" style="color: white;">logistique & transport</a></span><br><br>
                  <span class="sou"><a href="diver.php" style="color: white;">Divers</a></span>--> 
                </p>
              </div>
                <div class="mt-5" style="position: relative; transform:translateX(60px); ">
                <h1>Résultats de la Recherche</h1>
                <a href="../page/livre.php">
                          <button class="btn btn-warning">
                            <div class="container p-0">
                              <div class="d-flex">
                                <div>
                                <img src="../medias/annu.svg" >
                                </div>
                                <div>
                                <h6 class="fw-bold p-1" >Retour</h6>
                                </div>
                              </div>
                            </div>
                          </button>
                </a>
                        <br><br>
            <div id="search_results">
                </div>
                <?php
                include '../Includes/db_connect.php';

                if (isset($_GET['searchl'])) {
                    $search = $_GET['searchl'];
                    //$category_id = $_POST['categorie_id'];
                    //$author_id = $_POST['auteur_id'];

                    $sql = "SELECT livres.id, livres.title, auteurs.nom AS Auteur, catégories.nom AS Catégorie, livres.link, livres.description
                    FROM livres
                    JOIN auteurs ON livres.auteur_id = auteurs.id
                    JOIN catégories ON livres.categorie_id = catégories.id
                    WHERE livres.title LIKE ? OR auteurs.nom LIKE ? OR  catégories.nom LIKE ?";
                    $stmt = $conn->prepare($sql);
                    $search_param = "%" . $search . "%";
                    $stmt->bind_param("sss", $search_param, $search_param, $search_param);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    if ($result->num_rows > 0) {
                        echo "<table style=' width: 100%;'>";
                        echo "<thead><tr><th>ID</th><th>Titre</th><th>Auteur</th><th>Catégorie</th><th>Consulter</th></tr></thead>";
                        echo "<tbody>";
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            
                            echo "<td>" . ($row['id']) . "</td>";
                            echo "<td>" . ($row['title']) . "</td>";
                            echo "<td>" . ($row['Auteur']) . "</td>";
                            echo "<td>" . ($row['Catégorie']) . "</td>";
                            
                            echo "                                      <td class='action-buttons'>
                                        <div class='ms-2'>
                                          <a href='" . $row['link'] . "'> <img  src='../medias/eye.svg' title='Voir' style='background:yellow; padding:10px; margin-bottum:0; border-radius:20px' >
                                          <a/>
                                        </div>
                                       </td>";
                                
                            echo "</tr>";
                            
                        }
                        echo "</tbody></table>";
                    } else {
                        echo "Aucun livre trouvé";
                    }

                    $stmt->close();
                    $conn->close();
                } else {
                    echo "Aucun terme de recherche spécifié";
                }
                ?>
            </div>

              </div>
            
              
              <!-- Ajoutez plus de contenu ici si nécessaire -->
          </div>
                  
              </div>
        


      </div>
  </div>
</body>
</html>
