<?php
session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceuil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>
<body>
   <div id="hero1">
   <nav>
    <ul class="nav justify-content-center  ">
        <li class="nav-brand">
            <img src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" alt=""> 
        </li>
        <li class="nav-item">
          <a class="nav-link" href="acceuil.php"><h6>  Acceuil</h6></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php"><h6> <span>à</span> propos</h6></a>
        </li>
      </ul>
   </nav>
  <div style=" margin-top: 100px;">
    <div class="initiales">
        <p class="text-center">
            ISTAG-ESPIM
        </p>
       </div>
       <div class="initiales-txt">
        <p class="text-center">
            Bienvenue sur la bibliothèque Numérique de l'institut
        </p>
       </div>
       <div class="initiales-icons">
        <p class="text-center">
            <img src="../medias/femme.png" width="250" height="250" alt="">
            <a href="login.php"><button type="button" class="btn btn-info btn-lg" >Commencer !</button></a>
        </p>
       </div>
  </div>
   </div>


   <footer>
    <div class="container">
     <div>
      <h4 class="text-center" style="color: white; font-family: pop; text-decoration-line: underline;">ISTAG-ESPIM</h4>
     </div>
     <div class="row">
      <div class="col-3"></div>
      <div class="col-3">
        <p style="color: white; font-family: pop;">
          Direction Générale : <br> Baco Djicoroni ACI,<br>Rue 822, Porte 1780 <br><br>
          Annexe : <br> Djélibougou près du L.Kodonso 
        </p>
      </div>
      <div class="col-1"></div>
      <div class="col-3">
        <p style="color: white; font-family: pop;">
          Tel : <br> +223 20 74 11 37 / 74 47 57 33 <br> 60 12 50 56 / 90 55 55 82 <br><br>
          Email: <br> <a style="color: white;" href="mailto:istag@istagmali.com?subject=Sujet%20du%20mail&body=Contenu%20du%20mail">istag@istagmali.com</a> <br>
          <a style="color: white;" href="mailto:istag.mali@yahoo.com?subject=Sujet%20du%20mail&body=Contenu%20du%20mail">istag.mali@yahoo.com</a> 

        </p>
      </div>
     </div>
    </div>
   </footer>
  









   <script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>