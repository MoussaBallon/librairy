<?php
session_start();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authentification</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">                                                                                                           
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>
<body>
<section id="hero1">
    <nav >
        <ul class="nav justify-content-center  ">
            <li class="nav-item">
            <a class="nav-link" href="acceuil.php"><h6 style=" color: white;  font-family: pop; font-size:1.5rem;">  Acceuil</h6></a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="about.php"><h6 style="color: white;  font-family: pop; font-size:1.5rem;"> <span>à</span> propos</h6></a>
            </li>
        </ul>
   </nav>
   <img id="logo" src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" alt=""> 
    <div class="initiales">
        <p class="text-center" style="color: blue;  font-family: pop; font-size:3rem; margin-top:-10px;">
            ISTAG-ESPIM
        </p>
       </div>  
    <form id="log" action="../includes/login-2.php" method="POST">
    <legend style="text-align:center ; color: white;  font-family: pop;">Authentification</legend> <br>
        <div class="form_group">
        <label for="user_name" style="color: white;">Nom utilisateur:</label>
        <input type="text" id="user_name" name="user_name" required class="form-control" autocomplete="off">
        </div>
        <br>
        <!--<div class="form-group">
        <label for="email" style="color: white;">Email:</label>
        <input type="email" id="email" name="email" required class="form-control" autocomplete="off">
        </div> <br>-->
        <div class="form-group">
        <label for="password" style="color: white;">Mot de passe:</label>
        <input type="password" id="password" name="password" required class="form-control" autocomplete="off">
        </div> 
        <p style="color: white;">
        Mot de passe oublié? cliquez <a style="color: aqua;" href="signup.php">Ici</a>
        </p>
        
        
        <?php
        if (isset($_SESSION['error_message'])) {
            echo '<p style="color: red;">' . $_SESSION['error_message'] . '</p>';
            unset($_SESSION['error_message']); // Clear the error message after displaying it
        }
        ?>
        
        
        <button type="submit" name="envoi" class="btn btn-outline-success btn-lg" >Acceder </button>
        <p style="color: white;">
        Vous n'avez pas encore de compte ? Inscrivez-vous  <a style="color: aqua;" href="admin.php">Ici</a>
        </p> 
    </form>
    

    </div>
    </div>
    
    </section>
 </body>
 </html>


