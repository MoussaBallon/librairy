<?php
session_start();
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialisation</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">                                                                                                           
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>
<body>
<section id="hero1">
<nav>
    <ul class="nav justify-content-center  ">
        <li class="nav-item">
          <a class="nav-link" href="acceuil.php"><h6 style=" color: white;  font-family: pop; font-size:1.5rem;">  Acceuil</h6></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php"><h6 style="color: white;  font-family: pop; font-size:1.5rem;"> <span>à</span> propos</h6></a>
        </li>
      </ul>
   </nav>
   <img id="logo" src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" alt=""> 
  <div style=" margin-top: -20px;">
    <div class="initiales">
        <p class="text-center" style="color: blue;  font-family: pop; font-size:3rem; margin-top:10px;">
            ISTAG-ESPIM
        </p>
       </div>
   
    <form id="log" action="../includes/signup.php" method="POST">
        <legend style="text-align:center ; color: white;  font-family: pop;">Réinitialiser Mot de passe</legend> <br>
        <div class="form-group">
            <label for="user_name" style="color: white;">Nom utilisateur :</label> <br>
            <input type="text" id="user_name" name="user_name" required class="form-control" autocomplete="off" >
        </div> <br>
        <div class="form-group">
            <label for="mail" style="color: white;">Email:</label> <br>
            <input type="email" id="email" name="email" required class="form-control" autocomplete="off" >
        </div> <br>
        <div class="form-group">
            <label for="new_password" style="color: white;">Nouveau mot de passe :</label><br>
            <input  type="password" id="new_password" name="new_password" required autocomplete="off" class="form-control">
        </div> <br>
        <?php
        if (isset($_SESSION['error_message'])) {
            echo '<p style="color: red;">' . $_SESSION['error_message'] . '</p>';
            unset($_SESSION['error_message']); // Clear the error message after displaying it
        }
        //else{
          // echo $_SESSION['success_message'];
        //}
        ?>
        <div class="form-group">
            <label for="confirm_password" style="color: white;">Confimer mot le de passe :</label><br>
            <input  type="password" id="confirm_password" name="confirm_password" required autocomplete="off" class="form-control">
        </div> <br>
<!--  <p class="lien" style="color: white;">
                <a style="color: red;" href="reinit.html">Login ou Mot de passe oublié ?</a>
            </p>-->
            <button type="submit" name="envoi" class="btn btn-outline-success btn-lg" >Valider </button> 
            <p style="color: white;">
        Vous n'avez pas encore de compte ? Inscrivez-vous  <a style="color: aqua;" href="admin.php">Ici</a>
        </p> 
    </form>
   </section>
</body>
</html>



