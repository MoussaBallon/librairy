<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>bibliothèque</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
</head>
<body>
  <div id="hero1">
          <nav >
              <ul class="nav justify-content-center pt-3 ">
                  <li class="nav-brand">
                      <img src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" alt=""> 
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="acceuil.php"><h6>Acceuil</h6></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="about.php"><h6> <span>à</span> propos</h6></a>
                  </li>
                </ul>
            </nav>
            <span id="grc" class="">
              <img src="../medias/garçon lit.png" width="150" height="150" alt="">
            </span> 
            <div id="tableau2" style="margin-top: -110px;">
                
              <div class="container" id="navi">
                <div class="row">
                  <div class="col-12">
                    <p class="text-center" style="font-size: 20px; font-family: pop; font-weight: bold;"> <img src="../medias/book.png" width="50" height="50" alt=""> Bibliothèque_Logistique & trans</p>
                  </div>
                </div>
              </div>
            
              <div id="menu">
                <h2 class="text-center text-white" style="font-family: pop; font-weight: bold; font-size: 20px; padding-top: 10px; text-decoration: underline;">Menu</h2>
                <p class="text-center text-white pt-5 fw-bold">
                  <span class="sou" style="text-decoration: underline;"><a href="dev.php" style="color: white;">Developpement web</a></span> <br> <br>
                  <span class="sou"><a href="marketing.php" style="color: white;">Marqueting</a></span> <br><br>
                  <span class="sou"><a href="science.php" style="color: white;">Sciences Sociales</a></span><br><br>
                  <span class="sou"><a href="reseau.php" style="color: white;">Réseaux info & Télécommunication</a></span><br><br>
                  <span class="sou"><a href="logistic.php" style="color: white;">logistique & transport</a></span><br><br>
                  <span class="sou"><a href="diver.php" style="color: white;">Divers</a></span> 
                </p>
              </div>
            
            <span id="navi1" >
              <h6 style="margin-left: 400px; margin-top: -420px;">
                <ul >
                  <li>
                    <a href="categories.php">Catégories</a>
                  </li>
                  <li>
                    <a href="auteur.php">Auteurs</a>
                  </li>
                </ul>
              </h6>
            </span>
            <form class="d-flex" role="search" style="width:25%; margin-left: 250px; margin-bottom: 0; ">
              <input class="form-control me-2" type="search" placeholder="livre" aria-label="Search">
              <button class="btn btn-outline-success" type="submit">Chercher</button>
            </form>
            <div class="scroll-container">
              <div class="d-flex">
                <div class="card m-5" style="width: 18rem;">
                  <div class="card-body">
                    <h5 class="card-title"><img src="../medias/L1jpg.jpg" width="60px" height="80px" alt=""></h5>
                    <h6 class="card-subtitle mb-2 text-body-secondary">Dictionnaire des trans & logi</h6>
                    <p class="card-text"> Guide complet des termes clés du secteur du transport et de la logistique.</p>
                    <a href="L1.php" class="card-link">Voir résumé</a>
                  </div>
                </div>
                <div class="card m-5" style="width: 18rem;">
                  <div class="card-body">
                    <h5 class="card-title"><img src="../medias/L2.jpg" width="60px" height="80px" alt=""></h5>
                    <h6 class="card-subtitle mb-2 text-body-secondary">Transport et logistique</h6>
                    <p class="card-text"> Exploration des interconnexions entre finance, transport et logistique dans l'industrie moderne.</p>
                    <a href="L2.php" class="card-link">Voir résumé</a>
                  </div>
                </div>
              </div>
              <div class="d-flex">
                <div class="card m-5" style="width: 18rem;">
                  <div class="card-body">
                    <h5 class="card-title"><img src="../medias/L3.jpg" width="60px" height="80px" alt=""></h5>
                    <h6 class="card-subtitle mb-2 text-body-secondary">transport & logistic</h6>
                    <p class="card-text"> Manuel pratique couvrant les fondamentaux du transport et de la logistique contemporains.</p>
                    <a href="L3.php" class="card-link">Voir résumé</a>
                  </div>
                </div>
                <div class="card m-5" style="width: 18rem;">
                  <div class="card-body">
                    <h5 class="card-title"><img src="../medias/L4.jpg" width="60px" height="80px" alt=""></h5>
                    <h6 class="card-subtitle mb-2 text-body-secondary">transport & logistic</h6>
                    <p class="card-text">Recueil d'exercices interactifs pour renforcer la compréhension pratique des opérations logistiques.</p>
                    <a href="L4.php" class="card-link">Voir résumé</a>
                  </div>
                </div>
              </div>
              <div class="d-flex">
                <div class="card m-5" style="width: 18rem;">
                  <div class="card-body">
                    <h5 class="card-title"><img src="../medias/L5.jpg" width="60px" height="80px" alt=""></h5>
                    <h6 class="card-subtitle mb-2 text-body-secondary">logistic</h6>
                    <p class="card-text">Recueil d'exercices interactifs pour renforcer la compréhension pratique des opérations logistiques.</p>
                    <a href="L5.php" class="card-link">Voir résumé</a>
                  </div>
                </div>
                <div class="card m-5" style="width: 18rem;">
                  <div class="card-body">
                    <h5 class="card-title"><img src="../medias/L6.png" width="60px" height="80px" alt=""></h5>
                    <h6 class="card-subtitle mb-2 text-body-secondary">GTLA</h6>
                    <p class="card-text">Guide des Technologies de Logistique Avancée, explorant les innovations technologiques dans la gestion logistique.</p>
                    <a href="L6.php" class="card-link">Voir résumé</a>
                  </div>
                </div>
              </div>
              </div>
              
              <!-- Ajoutez plus de contenu ici si nécessaire -->
          </div>
                  
              </div>
        


      </div>
  </div>
</body>
</html>