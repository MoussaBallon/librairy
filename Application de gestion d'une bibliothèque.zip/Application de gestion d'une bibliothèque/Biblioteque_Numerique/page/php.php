<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceuil</title>
    <script src="script.js" defer></script>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
</head>
<body>
   <div id="hero1">
   <nav >
    <ul class="nav justify-content-center pt-3 ">
        <li class="nav-brand">
            <img src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" alt=""> 
        </li>
        <li class="nav-item">
          <a class="nav-link" href="Acceuil.html"><h6>  Acceuil</h6></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.html"><h6> <span>à</span> propos</h6></a>
        </li>
      </ul>
   </nav>

    <div>
        <div class="container" style="margin-left: 250px;">
            <div class="row">
                <div class="col-4">
                            <img  src="../medias/dev5.jpg" width="300px" height="450px" style="border-radius: 15px;"  alt="">
                </div>
                <div class="col-6" style="background-color: rgba(0, 0, 0, 0.295); border-radius: 15px; height: 250px; margin-top: 100px;">
                    <div class="container">
                        <div class="row">
                         <div class="col-3">
                                    <p style="color: white; font-family: pop;">Titre: <br>HTML5 & CSS3 <br> <br>
                                        Auteurs : Anne Boehm, Zak Ruvalcaba </p>
                         </div>
                         <div class="col-3">
                                <p  style="color: white; font-family: pop;">Éditeur : Mike Murach & Associates</p>
                         </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mt-5">
                <a target="_blank" href="../medias/PHP.pdf"><button class="btn btn-danger ">Telechager</button></a>
            </div>

                <div class="container">
                    <div class="row">
                        <div class="col-8"  style="background-color: rgba(0, 0, 0, 0.384); border-radius: 15px; margin-top: 100px;">
                            <p class="p-3" style="color: white; font-family: pop;">
                            
                                Édition recommandée : "Murach's HTML and CSS (5th Edition)"
                                Auteurs : Anne Boehm, Zak Ruvalcaba
                                Éditeur : Mike Murach & Associates
                                Date de publication : 1er avril 2021
                                ISBN : 978-1943872852
                                Description :
                                "Murach's HTML and CSS (5th Edition)" est un manuel complet et pratique conçu pour les débutants comme pour les développeurs expérimentés qui souhaitent approfondir leurs compétences en HTML et CSS.

                                Ce livre adopte une approche unique de présentation en double page :

                                La page de gauche fournit des explications claires et détaillées des concepts, des techniques et des pratiques liées au développement web.
                                La page de droite propose des exemples concrets de code et des exercices pour appliquer les concepts appris.
                                Contenu principal :
                                Introduction aux bases du HTML et CSS : Ce livre commence par les fondamentaux du HTML5 et du CSS3, expliquant comment structurer et styliser les pages web de manière efficace.
                                Conception responsive : Les auteurs mettent l'accent sur la création de sites web adaptatifs qui fonctionnent bien sur une variété d'appareils et de tailles d'écran.
                                Techniques avancées : Le livre couvre également des sujets avancés tels que les formulaires, les tableaux, les flexbox, les grilles CSS et les animations.
                                Projets pratiques : Plusieurs chapitres incluent des projets pratiques et des études de cas réels pour renforcer l'apprentissage et permettre aux lecteurs de voir comment appliquer les techniques dans des contextes réels.
                                Avec son approche didactique et ses exemples concrets, "Murach's HTML and CSS" est une ressource précieuse pour toute personne souhaitant maîtriser la création de sites web modernes et attrayants.

                            </p>
                        </div>
                    </div>
                </div>
        </div>
    </div>
  









   <script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>