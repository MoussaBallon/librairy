<?php
session_start();
include '../includes/db_connect.php';

// Vérifier si l'utilisateur est connecté et s'il est administrateur
if (!isset($_SESSION['user_name']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Le reste de votre code d'administration
// Récupérer l'ID de l'auteur depuis l'URL
if (isset($_GET['id'])) {
  $author_id = $_GET['id'];

  // Récupérer les informations de l'auteur depuis la base de données
  $sql = "SELECT nom, bio FROM auteurs WHERE id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $author_id);
  $stmt->execute();
  $stmt->bind_result($nom, $bio);
  $stmt->fetch();
  $stmt->close();
} else {
  // Rediriger si l'ID n'est pas défini
  header("Location:../page/admin_list.aut.php");
  exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/">
</head>
<body>
  <div id="hero1">
          <nav >
              <ul class="nav justify-content-center pt-3 ">
                  <li class="nav-item">
                    <a class="nav-link" href="acceuil.php"><h6>Acceuil</h6></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="about.php"><h6> <span>à</span> propos</h6></a>
                  </li>
                </ul>
            </nav>
            <div class="container">
          <div class="row">
            <div class="col-1">
                  <img src="../medias/ISTAG-Mali-etudes-supérieures-mali-orientation-edukiya.png" style="width:100px; height:100px; border-radius: 100px;" alt=""> 
            </div>
            <div class="col-2"></div>
              <div class="col-8">
                <h1 style="margin-left: 100px; margin-top: 10px; ; font-family:pop; color: white; opacity:0;
                  transform: translateX(-100px);
                  animation: apparition 1.2s  0.9s ease-out forwards;" >
                    <span id="slt">
                        <img src="../medias/slt.png" width="50" height="50" alt="">
                      </span>
                    Bienvenue monsieur, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!
                </h1>
              </div>
              <div class="col-1 mt-4">
              <a href="../includes/logout.php"> <button class="btn btn-primary ">Deconnexion</button></a>
              </div>
          </div>
        </div>
            <div id="tableau2" style="margin-top: 20px;">
                
              <div class="container" id="navi">
                <div class="row">
                  <div class="col-12">
                    <p class="text-center" style="font-size: 20px; font-family: pop; font-weight: bold;"> <img src="../medias/book.png" width="50" height="50" alt=""> Bibliothèque</p>
                  </div>
                </div>
              </div>  
              <div class="d-flex">
              <div id="menu">
                <p style="color: white; font-family:pop; font-size:30px; text-align: center; text-decoration-line: underline">
                  Menu
                </p>
                <ul style="list-style: none;">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" style="color:white; font-size:30px; position: relarelative; transform: translateX(-40px); " data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"> <img src="../medias/people.svg" width="50" height="40" alt="">Auteurs</a><br>
                        <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="admin_list_aut.php"> <img src="../medias/list-columns.svg" alt=""> Liste</a></li><br>
                        <li><a class="dropdown-item" href="admin_ajou_aut.php"> <img src="../medias/file-earmark-plus.svg" alt=""> Ajouter</a></li><br>
                        
                        </ul>
                    </li>
                </ul>
                <ul style="list-style: none;">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" style="color:white; font-size:30px; transform: translateX(-50px);" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"> <img src="../medias/list-columns.svg" width="30" height="30" alt=""> Catégories</a><br>
                        <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="admin_list_cat.php"> <img src="../medias/list-columns.svg" alt=""> Liste</a></li><br>
                        <li><a class="dropdown-item" href="admin_ajou_cat.php"> <img src="../medias/file-earmark-plus.svg" alt=""> Ajouter</a></li><br>
                        
                      
                        </ul>
                    </li>
                </ul>
                <ul style="list-style: none;">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" style="color:white; font-size:30px; position: relarelative; transform: translateX(-55px);" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"> <img src="../medias/book.png" width="50" height="50" alt=""> Ouvrages</a><br>
                        <ul class="dropdown-menu">
                          <li><a class="dropdown-item" href="admin_list_liv.php"> <img src="../medias/list-columns.svg" alt=""> Liste</a></li><br>
                          <li><a class="dropdown-item" href="admin_ajou_liv.php"> <img src="../medias/file-earmark-plus.svg" alt=""> Ajouter</a></li><br>
                          
                      
                        </ul>
                    </li>
                </ul>
                <ul style="list-style: none">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" style="color:white; font-size:30px; position: relarelative; transform: translateX(-40px); " data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"> <img src="../medias/people.svg" width="50" height="40" alt="">Etudiants</a><br>
                        <ul class="dropdown-menu">
                          <li><a class="dropdown-item" href="admin_list_etu.php"> <img src="../medias/person-lines-fill.svg" alt=""> Liste</a></li><br>
                          <li><a class="dropdown-item" href="admin_ajou_etu.php"> <img src="../medias/person-add.svg" alt=""> Ajouter</a></li><br>
                          
                        </ul>
                    </li>
                </ul>
            </div>
              <div>
              <form action="../includes/trait_modif_aut.php" method="POST" style="background:none;margin-left: 200px; margin-top:30px; ">
                <legend>Modifier l'auteur</legend>
                  <input type="hidden" name="id" value="<?php echo $author_id; ?>">
                  <label for="nom">Nom de l'auteur:</label>
                  <input type="text" name="nom" id="nom" value="<?php echo htmlspecialchars($nom); ?>" required class="form-control  " autocomplete="off">
                  <br><br>
                  <label for="bio">Biographie:</label>
                  <textarea name="bio" id="bio" required class="form-control" style="height:150px;" autocomplete="off"><?php echo htmlspecialchars($bio); ?></textarea>
                  <br>
                  <div class="container d-flex">
                    <div>
                      <button class="btn btn-success" style="border-radius:100px" name="update" type="submit">Mettre à jour</button>
                    </div>
                    <div style="border-radius: 100px; position: relative; transform:translateX(100px);">
                        <button name="annuler"  class="btn btn-danger" style="width:150px; border-radius:100px;"><img src="../medias/annu.svg" alt=""> Annuler</button>
                    </div>
                  </div>
              </form>
              </div>
              </div>  
            
              
              <!-- Ajoutez plus de contenu ici si nécessaire -->
          </div>
                  
              </div>
        


      </div>
  </div>
</body>
</html>
